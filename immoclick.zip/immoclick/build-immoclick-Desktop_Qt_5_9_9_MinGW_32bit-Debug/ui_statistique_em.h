/********************************************************************************
** Form generated from reading UI file 'statistique_em.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTIQUE_EM_H
#define UI_STATISTIQUE_EM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_statistique_em
{
public:
    QLabel *label;
    QWidget *widget_3;
    QLabel *label_5;
    QWidget *widget_5;
    QLabel *label_6;
    QLabel *label_8;
    QWidget *widget;
    QWidget *widget_4;
    QLabel *label_2;
    QLabel *label_4;
    QWidget *widget_2;
    QLabel *label_3;

    void setupUi(QDialog *statistique_em)
    {
        if (statistique_em->objectName().isEmpty())
            statistique_em->setObjectName(QStringLiteral("statistique_em"));
        statistique_em->resize(916, 623);
        label = new QLabel(statistique_em);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(546, 50, 131, 31));
        label->setStyleSheet(QStringLiteral("font: 75 italic 14pt \"Arial\";"));
        widget_3 = new QWidget(statistique_em);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(550, 211, 21, 20));
        widget_3->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"background-color: rgb(255, 0, 0);"));
        label_5 = new QLabel(statistique_em);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(580, 181, 111, 16));
        label_5->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        widget_5 = new QWidget(statistique_em);
        widget_5->setObjectName(QStringLiteral("widget_5"));
        widget_5->setGeometry(QRect(550, 111, 20, 20));
        widget_5->setStyleSheet(QStringLiteral("background-color: rgb(0, 255, 0);"));
        label_6 = new QLabel(statistique_em);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(580, 211, 111, 16));
        label_6->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_8 = new QLabel(statistique_em);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(100, 480, 481, 41));
        label_8->setStyleSheet(QLatin1String("font: 18pt \"MS Shell Dlg 2\";\n"
"color: rgb(0, 170, 255);"));
        widget = new QWidget(statistique_em);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(550, 81, 20, 20));
        widget->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 255);"));
        widget_4 = new QWidget(statistique_em);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        widget_4->setGeometry(QRect(550, 181, 20, 20));
        widget_4->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"background-color: rgb(255, 255, 0);"));
        label_2 = new QLabel(statistique_em);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(580, 81, 111, 16));
        label_2->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_4 = new QLabel(statistique_em);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(580, 151, 131, 16));
        label_4->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        widget_2 = new QWidget(statistique_em);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(550, 151, 20, 20));
        widget_2->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        label_3 = new QLabel(statistique_em);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(580, 111, 111, 16));
        label_3->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));

        retranslateUi(statistique_em);

        QMetaObject::connectSlotsByName(statistique_em);
    } // setupUi

    void retranslateUi(QDialog *statistique_em)
    {
        statistique_em->setWindowTitle(QApplication::translate("statistique_em", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("statistique_em", "Pourcentage", Q_NULLPTR));
        label_5->setText(QApplication::translate("statistique_em", "Sfax", Q_NULLPTR));
        label_6->setText(QApplication::translate("statistique_em", "Sousse", Q_NULLPTR));
        label_8->setText(QApplication::translate("statistique_em", " statistique d'Adresse ", Q_NULLPTR));
        label_2->setText(QApplication::translate("statistique_em", "Bizerte", Q_NULLPTR));
        label_4->setText(QApplication::translate("statistique_em", "Nabeul", Q_NULLPTR));
        label_3->setText(QApplication::translate("statistique_em", "Tunis", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class statistique_em: public Ui_statistique_em {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTIQUE_EM_H
