/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *tab_employe;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QLabel *qrCode;
    QTabWidget *tabWidget_3;
    QWidget *tab;
    QPushButton *stat_salaire_emp;
    QLineEdit *id_supp;
    QLineEdit *rechercher_emp;
    QPushButton *tri_salaireemp;
    QPushButton *pdfemp;
    QPushButton *afficher_employer;
    QPushButton *tri_id_emp;
    QPushButton *tri_nom_emp;
    QPushButton *ajouteremployer;
    QTableView *tab_emp;
    QPushButton *statistique_employer;
    QPushButton *supprimer_employer;
    QLabel *label_40;
    QLabel *label_43;
    QFrame *frame_8;
    QLabel *qrcodeLabel;
    QTabWidget *tabWidget_4;
    QWidget *tab_3;
    QLabel *label_155;
    QLabel *label_163;
    QLabel *label_17;
    QLabel *label_18;
    QLineEdit *email;
    QLineEdit *salaire;
    QLabel *label_19;
    QLineEdit *prenom;
    QLabel *label_20;
    QLineEdit *nom;
    QLabel *label_21;
    QLineEdit *id;
    QLineEdit *ref_agence;
    QComboBox *adresse;
    QFrame *frame_9;
    QWidget *tab_8;
    QPushButton *modifier_emp;
    QLabel *label_22;
    QLineEdit *agence_modif;
    QLabel *label_23;
    QLabel *label_24;
    QLineEdit *prenom_modif;
    QLabel *label_25;
    QLabel *label_26;
    QLineEdit *id_modif;
    QLineEdit *nom_modif;
    QLabel *label_27;
    QLineEdit *email_modif;
    QLabel *label_28;
    QLineEdit *salaire_modif;
    QComboBox *adresse_modif;
    QFrame *frame_11;
    QWidget *tab_2;
    QGroupBox *groupBox;
    QLabel *label_29;
    QLabel *label_30;
    QLabel *label_31;
    QLineEdit *ID;
    QLineEdit *EMAIL;
    QLineEdit *MDP;
    QPushButton *Supprimer;
    QPushButton *Modifier;
    QPushButton *Afficher;
    QPushButton *Ajouter;
    QFrame *frame_14;
    QTableView *tableau_2;
    QLabel *label_39;
    QFrame *frame_10;
    QFrame *frame_7;
    QWidget *page_2;
    QWidget *widget_2;
    QPushButton *login;
    QLineEdit *email_login;
    QLineEdit *mdp_login;
    QLabel *label_32;
    QLabel *label_34;
    QLabel *label_33;
    QLabel *label_35;
    QFrame *frame_6;
    QFrame *frame_5;
    QWidget *tab_client;
    QFrame *frame;
    QTabWidget *tabWidget_2;
    QWidget *tab_6;
    QPushButton *trinomclient;
    QGroupBox *groupBox_emplye_5;
    QLabel *label_47;
    QLabel *label_48;
    QLabel *label_49;
    QLabel *label_50;
    QLineEdit *linenom;
    QLineEdit *lineEdit_prenom;
    QLineEdit *lineEdit_email;
    QLabel *label_51;
    QLineEdit *lineEditID;
    QComboBox *lineEdit_ad;
    QLabel *label_13;
    QLabel *label_14;
    QFrame *frame_16;
    QPushButton *supprimerclient;
    QPushButton *ajouterclient;
    QPushButton *modifierclient;
    QPushButton *triprenomclient;
    QPushButton *tri_idclient;
    QLineEdit *rechercher;
    QPushButton *afficherclient;
    QPushButton *statistiqueclient;
    QPushButton *export_excel;
    QLabel *label_37;
    QFrame *frame_12;
    QLabel *qrcodeLabel_2;
    QTableView *tableau;
    QPushButton *pushButton;
    QWidget *tab_5;
    QLabel *label_12;
    QLineEdit *port;
    QLineEdit *paswd;
    QLabel *label_10;
    QLabel *label_7;
    QPushButton *sendBtn;
    QLineEdit *rcpt;
    QLabel *label_6;
    QPushButton *exitBtn;
    QLabel *label_9;
    QLineEdit *uname;
    QLabel *label_11;
    QLineEdit *subject;
    QLineEdit *server;
    QLabel *label_8;
    QLabel *label_38;
    QFrame *frame_17;
    QPlainTextEdit *msg;
    QWidget *tab_agence;
    QPushButton *pushButton_supprimer;
    QLabel *label;
    QPushButton *pushButton_imprimer;
    QLineEdit *lineEdit_recherche;
    QPushButton *pushButton_ajouter;
    QGroupBox *groupBox_emplye;
    QLabel *label_1;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit_id;
    QLineEdit *lineEdit_budget;
    QLabel *label_4;
    QLineEdit *lineEdit_nbr_employe;
    QComboBox *comboBox_adresse;
    QFrame *frame_15;
    QPushButton *pushButton_tri_id;
    QPushButton *pushButton_modifier;
    QPushButton *pushButton_tri_budget;
    QPushButton *pushButton_tri_nbr_employe;
    QPushButton *pushButton_tri_nbr_client;
    QPushButton *pushButton_statistique;
    QLineEdit *lineEdit_supprimer;
    QTableView *tableView;
    QLabel *label_5;
    QLabel *label_36;
    QFrame *frame_13;
    QWidget *tab_bien;
    QLabel *label_41;
    QFrame *frame_18;
    QLineEdit *id_supp_2;
    QComboBox *comboBox;
    QPushButton *ajouter_bien;
    QPushButton *actualiser;
    QTabWidget *tabWidget_5;
    QWidget *tab_4;
    QLabel *label_44;
    QLineEdit *id_2;
    QLabel *label_45;
    QLabel *label_46;
    QLabel *label_52;
    QLabel *label_53;
    QLineEdit *prix_2;
    QLineEdit *categorie_2;
    QLineEdit *adresse_2;
    QComboBox *statu;
    QFrame *frame_19;
    QWidget *tab_7;
    QLabel *label_54;
    QLineEdit *id_modif_2;
    QLabel *label_55;
    QLineEdit *catg_modif2;
    QLabel *label_56;
    QLineEdit *prix_modif2;
    QLabel *label_57;
    QLineEdit *adresse_modif_2;
    QLabel *label_58;
    QPushButton *modifier_bien;
    QComboBox *satut_modif;
    QFrame *frame_20;
    QWidget *tab_9;
    QFrame *frame_22;
    QPushButton *ouvrir;
    QPushButton *Fermer;
    QLabel *label_59;
    QLabel *label_60;
    QPushButton *statistique_bien;
    QLineEdit *rechercher_bien;
    QPushButton *supprimer_bien;
    QLabel *error;
    QLabel *label_16;
    QLabel *label_15;
    QTableView *tab_bien_2;
    QWidget *tab_reclamation;
    QLabel *label_42;
    QLineEdit *rechercher_rec;
    QGroupBox *groupBox_emplye_2;
    QLabel *label_71;
    QLabel *label_72;
    QLabel *label_73;
    QLabel *label_74;
    QLineEdit *lientype;
    QLineEdit *lineEdit_description;
    QLineEdit *lineEdit_titre;
    QLabel *label_75;
    QLineEdit *lineEditIDreclamation;
    QLineEdit *lineEdit_date;
    QFrame *frame_24;
    QTableView *tableaurec;
    QLabel *label_61;
    QPushButton *pushButton_ajouter_2;
    QPushButton *pushButton_ajouter_3;
    QPushButton *chatbot;
    QPushButton *pushButton_7;
    QPushButton *pushButton_merier1_3;
    QPushButton *pushButton_supprimer_2;
    QPushButton *pushButton_merier1_2;
    QFrame *frame_21;
    QPushButton *pushButton_modifier_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1080, 685);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(10, 20, 1071, 631));
        tabWidget->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QTableView\n"
"{\n"
"background-color: rbga(255, 255, 255);\n"
"}\n"
"QplainTextEdit\n"
"{\n"
"background-color:(255,255,255,255);\n"
"}\n"
"QplainTextEdit\n"
"{\n"
"background-color:rbg(255,255,255,255);\n"
"}"));
        tab_employe = new QWidget();
        tab_employe->setObjectName(QStringLiteral("tab_employe"));
        stackedWidget = new QStackedWidget(tab_employe);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(10, 0, 1061, 721));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        qrCode = new QLabel(page);
        qrCode->setObjectName(QStringLiteral("qrCode"));
        qrCode->setGeometry(QRect(100, 370, 611, 271));
        tabWidget_3 = new QTabWidget(page);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setGeometry(QRect(0, 10, 1031, 641));
        tabWidget_3->setStyleSheet(QLatin1String("#MyLoginForm {\n"
"background: gray;\n"
"}\n"
"\n"
"\n"
"#mainFrame {\n"
"border: 3px solid gray;\n"
"border-radius: 40px;\n"
"background: white;\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        stat_salaire_emp = new QPushButton(tab);
        stat_salaire_emp->setObjectName(QStringLiteral("stat_salaire_emp"));
        stat_salaire_emp->setGeometry(QRect(160, 10, 91, 23));
        id_supp = new QLineEdit(tab);
        id_supp->setObjectName(QStringLiteral("id_supp"));
        id_supp->setEnabled(true);
        id_supp->setGeometry(QRect(634, 380, 113, 20));
        rechercher_emp = new QLineEdit(tab);
        rechercher_emp->setObjectName(QStringLiteral("rechercher_emp"));
        rechercher_emp->setGeometry(QRect(470, 10, 141, 24));
        rechercher_emp->setClearButtonEnabled(true);
        tri_salaireemp = new QPushButton(tab);
        tri_salaireemp->setObjectName(QStringLiteral("tri_salaireemp"));
        tri_salaireemp->setGeometry(QRect(634, 10, 101, 23));
        pdfemp = new QPushButton(tab);
        pdfemp->setObjectName(QStringLiteral("pdfemp"));
        pdfemp->setGeometry(QRect(270, 10, 91, 23));
        afficher_employer = new QPushButton(tab);
        afficher_employer->setObjectName(QStringLiteral("afficher_employer"));
        afficher_employer->setGeometry(QRect(120, 380, 75, 23));
        tri_id_emp = new QPushButton(tab);
        tri_id_emp->setObjectName(QStringLiteral("tri_id_emp"));
        tri_id_emp->setGeometry(QRect(380, 10, 75, 23));
        tri_nom_emp = new QPushButton(tab);
        tri_nom_emp->setObjectName(QStringLiteral("tri_nom_emp"));
        tri_nom_emp->setGeometry(QRect(740, 10, 75, 23));
        ajouteremployer = new QPushButton(tab);
        ajouteremployer->setObjectName(QStringLiteral("ajouteremployer"));
        ajouteremployer->setGeometry(QRect(20, 380, 75, 23));
        tab_emp = new QTableView(tab);
        tab_emp->setObjectName(QStringLiteral("tab_emp"));
        tab_emp->setGeometry(QRect(70, 60, 791, 121));
        tab_emp->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        statistique_employer = new QPushButton(tab);
        statistique_employer->setObjectName(QStringLiteral("statistique_employer"));
        statistique_employer->setGeometry(QRect(64, 10, 91, 23));
        supprimer_employer = new QPushButton(tab);
        supprimer_employer->setObjectName(QStringLiteral("supprimer_employer"));
        supprimer_employer->setGeometry(QRect(754, 380, 101, 23));
        label_40 = new QLabel(tab);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setGeometry(QRect(10, 420, 101, 121));
        label_40->setPixmap(QPixmap(QString::fromUtf8(":/logo/logo1.png")));
        label_43 = new QLabel(tab);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setGeometry(QRect(870, 20, 101, 121));
        label_43->setPixmap(QPixmap(QString::fromUtf8(":/logo/logo1.png")));
        frame_8 = new QFrame(tab);
        frame_8->setObjectName(QStringLiteral("frame_8"));
        frame_8->setGeometry(QRect(-50, -30, 1091, 741));
        frame_8->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Raised);
        qrcodeLabel = new QLabel(frame_8);
        qrcodeLabel->setObjectName(QStringLiteral("qrcodeLabel"));
        qrcodeLabel->setGeometry(QRect(260, 380, 401, 211));
        tabWidget_4 = new QTabWidget(frame_8);
        tabWidget_4->setObjectName(QStringLiteral("tabWidget_4"));
        tabWidget_4->setGeometry(QRect(120, 230, 801, 151));
        tabWidget_4->setStyleSheet(QLatin1String("QComboBox{\n"
"\n"
"background-color:#405361;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"color: white;\n"
"}"));
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        label_155 = new QLabel(tab_3);
        label_155->setObjectName(QStringLiteral("label_155"));
        label_155->setGeometry(QRect(216, 30, 71, 20));
        label_163 = new QLabel(tab_3);
        label_163->setObjectName(QStringLiteral("label_163"));
        label_163->setGeometry(QRect(496, 60, 61, 20));
        label_17 = new QLabel(tab_3);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(496, 20, 61, 20));
        label_18 = new QLabel(tab_3);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(30, 60, 51, 20));
        email = new QLineEdit(tab_3);
        email->setObjectName(QStringLiteral("email"));
        email->setGeometry(QRect(580, 90, 113, 20));
        salaire = new QLineEdit(tab_3);
        salaire->setObjectName(QStringLiteral("salaire"));
        salaire->setGeometry(QRect(580, 60, 113, 20));
        label_19 = new QLabel(tab_3);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(496, 90, 61, 20));
        prenom = new QLineEdit(tab_3);
        prenom->setObjectName(QStringLiteral("prenom"));
        prenom->setGeometry(QRect(300, 30, 113, 20));
        label_20 = new QLabel(tab_3);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(40, 30, 51, 20));
        nom = new QLineEdit(tab_3);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setGeometry(QRect(80, 60, 113, 20));
        label_21 = new QLabel(tab_3);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(216, 60, 71, 20));
        id = new QLineEdit(tab_3);
        id->setObjectName(QStringLiteral("id"));
        id->setGeometry(QRect(80, 30, 113, 20));
        ref_agence = new QLineEdit(tab_3);
        ref_agence->setObjectName(QStringLiteral("ref_agence"));
        ref_agence->setGeometry(QRect(580, 20, 113, 20));
        adresse = new QComboBox(tab_3);
        adresse->setObjectName(QStringLiteral("adresse"));
        adresse->setGeometry(QRect(300, 60, 111, 22));
        frame_9 = new QFrame(tab_3);
        frame_9->setObjectName(QStringLiteral("frame_9"));
        frame_9->setGeometry(QRect(0, 0, 851, 121));
        frame_9->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.jpg)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QComboBox{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}"));
        frame_9->setFrameShape(QFrame::StyledPanel);
        frame_9->setFrameShadow(QFrame::Raised);
        tabWidget_4->addTab(tab_3, QString());
        frame_9->raise();
        label_155->raise();
        label_163->raise();
        label_17->raise();
        label_18->raise();
        email->raise();
        salaire->raise();
        label_19->raise();
        prenom->raise();
        label_20->raise();
        nom->raise();
        label_21->raise();
        id->raise();
        ref_agence->raise();
        adresse->raise();
        tab_8 = new QWidget();
        tab_8->setObjectName(QStringLiteral("tab_8"));
        modifier_emp = new QPushButton(tab_8);
        modifier_emp->setObjectName(QStringLiteral("modifier_emp"));
        modifier_emp->setGeometry(QRect(650, 50, 75, 23));
        label_22 = new QLabel(tab_8);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(10, 40, 41, 20));
        agence_modif = new QLineEdit(tab_8);
        agence_modif->setObjectName(QStringLiteral("agence_modif"));
        agence_modif->setGeometry(QRect(520, 10, 113, 20));
        label_23 = new QLabel(tab_8);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(450, 40, 61, 20));
        label_24 = new QLabel(tab_8);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(450, 70, 51, 16));
        prenom_modif = new QLineEdit(tab_8);
        prenom_modif->setObjectName(QStringLiteral("prenom_modif"));
        prenom_modif->setGeometry(QRect(290, 10, 113, 20));
        label_25 = new QLabel(tab_8);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(200, 50, 81, 16));
        label_26 = new QLabel(tab_8);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(10, 10, 41, 20));
        id_modif = new QLineEdit(tab_8);
        id_modif->setObjectName(QStringLiteral("id_modif"));
        id_modif->setGeometry(QRect(60, 10, 113, 20));
        nom_modif = new QLineEdit(tab_8);
        nom_modif->setObjectName(QStringLiteral("nom_modif"));
        nom_modif->setGeometry(QRect(60, 40, 113, 20));
        label_27 = new QLabel(tab_8);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setGeometry(QRect(440, 10, 71, 16));
        email_modif = new QLineEdit(tab_8);
        email_modif->setObjectName(QStringLiteral("email_modif"));
        email_modif->setGeometry(QRect(520, 70, 113, 20));
        label_28 = new QLabel(tab_8);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setGeometry(QRect(210, 10, 81, 16));
        salaire_modif = new QLineEdit(tab_8);
        salaire_modif->setObjectName(QStringLiteral("salaire_modif"));
        salaire_modif->setGeometry(QRect(520, 40, 113, 20));
        adresse_modif = new QComboBox(tab_8);
        adresse_modif->setObjectName(QStringLiteral("adresse_modif"));
        adresse_modif->setGeometry(QRect(290, 50, 111, 22));
        frame_11 = new QFrame(tab_8);
        frame_11->setObjectName(QStringLiteral("frame_11"));
        frame_11->setGeometry(QRect(-20, 0, 821, 151));
        frame_11->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.jpg)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_11->setFrameShape(QFrame::StyledPanel);
        frame_11->setFrameShadow(QFrame::Raised);
        tabWidget_4->addTab(tab_8, QString());
        frame_11->raise();
        modifier_emp->raise();
        label_22->raise();
        agence_modif->raise();
        label_23->raise();
        label_24->raise();
        prenom_modif->raise();
        label_25->raise();
        label_26->raise();
        id_modif->raise();
        nom_modif->raise();
        label_27->raise();
        email_modif->raise();
        label_28->raise();
        salaire_modif->raise();
        adresse_modif->raise();
        tabWidget_3->addTab(tab, QString());
        frame_8->raise();
        rechercher_emp->raise();
        supprimer_employer->raise();
        stat_salaire_emp->raise();
        tri_salaireemp->raise();
        pdfemp->raise();
        tri_id_emp->raise();
        tri_nom_emp->raise();
        statistique_employer->raise();
        id_supp->raise();
        ajouteremployer->raise();
        afficher_employer->raise();
        label_40->raise();
        label_43->raise();
        tab_emp->raise();
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        groupBox = new QGroupBox(tab_2);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(160, 210, 651, 141));
        label_29 = new QLabel(groupBox);
        label_29->setObjectName(QStringLiteral("label_29"));
        label_29->setGeometry(QRect(30, 50, 47, 14));
        label_30 = new QLabel(groupBox);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setGeometry(QRect(380, 50, 121, 16));
        label_31 = new QLabel(groupBox);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(200, 50, 47, 14));
        ID = new QLineEdit(groupBox);
        ID->setObjectName(QStringLiteral("ID"));
        ID->setGeometry(QRect(70, 50, 113, 20));
        EMAIL = new QLineEdit(groupBox);
        EMAIL->setObjectName(QStringLiteral("EMAIL"));
        EMAIL->setGeometry(QRect(250, 50, 113, 20));
        MDP = new QLineEdit(groupBox);
        MDP->setObjectName(QStringLiteral("MDP"));
        MDP->setGeometry(QRect(510, 50, 113, 20));
        Supprimer = new QPushButton(groupBox);
        Supprimer->setObjectName(QStringLiteral("Supprimer"));
        Supprimer->setGeometry(QRect(380, 100, 75, 23));
        Modifier = new QPushButton(groupBox);
        Modifier->setObjectName(QStringLiteral("Modifier"));
        Modifier->setGeometry(QRect(480, 100, 75, 23));
        Afficher = new QPushButton(groupBox);
        Afficher->setObjectName(QStringLiteral("Afficher"));
        Afficher->setGeometry(QRect(270, 100, 75, 23));
        Ajouter = new QPushButton(groupBox);
        Ajouter->setObjectName(QStringLiteral("Ajouter"));
        Ajouter->setGeometry(QRect(170, 100, 75, 23));
        frame_14 = new QFrame(groupBox);
        frame_14->setObjectName(QStringLiteral("frame_14"));
        frame_14->setGeometry(QRect(0, 0, 661, 141));
        frame_14->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.jpg)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_14->setFrameShape(QFrame::StyledPanel);
        frame_14->setFrameShadow(QFrame::Raised);
        frame_14->raise();
        label_29->raise();
        label_30->raise();
        label_31->raise();
        ID->raise();
        EMAIL->raise();
        MDP->raise();
        Supprimer->raise();
        Modifier->raise();
        Afficher->raise();
        Ajouter->raise();
        tableau_2 = new QTableView(tab_2);
        tableau_2->setObjectName(QStringLiteral("tableau_2"));
        tableau_2->setGeometry(QRect(130, 70, 731, 121));
        tableau_2->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        tableau_2->setSortingEnabled(true);
        tableau_2->horizontalHeader()->setCascadingSectionResizes(true);
        tableau_2->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        tableau_2->horizontalHeader()->setStretchLastSection(false);
        label_39 = new QLabel(tab_2);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setGeometry(QRect(10, 10, 101, 121));
        label_39->setPixmap(QPixmap(QString::fromUtf8(":/logo/logo1.png")));
        frame_10 = new QFrame(tab_2);
        frame_10->setObjectName(QStringLiteral("frame_10"));
        frame_10->setGeometry(QRect(0, 0, 1071, 681));
        frame_10->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_10->setFrameShape(QFrame::StyledPanel);
        frame_10->setFrameShadow(QFrame::Raised);
        tabWidget_3->addTab(tab_2, QString());
        frame_10->raise();
        groupBox->raise();
        tableau_2->raise();
        label_39->raise();
        frame_7 = new QFrame(page);
        frame_7->setObjectName(QStringLiteral("frame_7"));
        frame_7->setGeometry(QRect(-50, 0, 1131, 671));
        frame_7->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_7->setFrameShape(QFrame::StyledPanel);
        frame_7->setFrameShadow(QFrame::Raised);
        stackedWidget->addWidget(page);
        frame_7->raise();
        qrCode->raise();
        tabWidget_3->raise();
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        widget_2 = new QWidget(page_2);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(110, 50, 631, 401));
        widget_2->setStyleSheet(QStringLiteral("background: rgb(255, 255, 255)"));
        login = new QPushButton(widget_2);
        login->setObjectName(QStringLiteral("login"));
        login->setGeometry(QRect(370, 220, 93, 28));
        email_login = new QLineEdit(widget_2);
        email_login->setObjectName(QStringLiteral("email_login"));
        email_login->setGeometry(QRect(350, 150, 141, 22));
        email_login->setStyleSheet(QStringLiteral("background: rgb(255, 255, 255)"));
        mdp_login = new QLineEdit(widget_2);
        mdp_login->setObjectName(QStringLiteral("mdp_login"));
        mdp_login->setGeometry(QRect(350, 190, 141, 20));
        mdp_login->setEchoMode(QLineEdit::Password);
        label_32 = new QLabel(widget_2);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setGeometry(QRect(350, 80, 161, 51));
        QFont font;
        font.setFamily(QStringLiteral("Century Gothic"));
        font.setBold(true);
        font.setUnderline(true);
        font.setWeight(75);
        label_32->setFont(font);
        label_32->setStyleSheet(QStringLiteral("background: rgb(255, 255, 255)"));
        label_34 = new QLabel(widget_2);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setGeometry(QRect(290, 150, 56, 16));
        label_34->setStyleSheet(QStringLiteral("background: rgb(255, 255, 255)"));
        label_33 = new QLabel(widget_2);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setGeometry(QRect(270, 190, 71, 20));
        label_33->setStyleSheet(QStringLiteral("background: rgb(255, 255, 255)"));
        label_35 = new QLabel(widget_2);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(40, 70, 221, 251));
        label_35->setPixmap(QPixmap(QString::fromUtf8(":/logo/logo.png")));
        frame_6 = new QFrame(page_2);
        frame_6->setObjectName(QStringLiteral("frame_6"));
        frame_6->setGeometry(QRect(0, -10, 1071, 601));
        frame_6->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_6->setFrameShape(QFrame::StyledPanel);
        frame_6->setFrameShadow(QFrame::Raised);
        stackedWidget->addWidget(page_2);
        frame_6->raise();
        widget_2->raise();
        frame_5 = new QFrame(tab_employe);
        frame_5->setObjectName(QStringLiteral("frame_5"));
        frame_5->setGeometry(QRect(0, 0, 1071, 681));
        frame_5->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        tabWidget->addTab(tab_employe, QString());
        frame_5->raise();
        stackedWidget->raise();
        tab_client = new QWidget();
        tab_client->setObjectName(QStringLiteral("tab_client"));
        frame = new QFrame(tab_client);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setGeometry(QRect(0, 0, 1071, 601));
        frame->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QTableView\n"
"{\n"
"	background-color:rgb(255,255,255,255);\n"
"}"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        tabWidget_2 = new QTabWidget(frame);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        tabWidget_2->setGeometry(QRect(50, 20, 941, 521));
        tabWidget_2->setStyleSheet(QLatin1String("#MyLoginForm {\n"
"background: gray;\n"
"}\n"
"\n"
"\n"
"#mainFrame {\n"
"border: 3px solid gray;\n"
"border-radius: 40px;\n"
"background: white;\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QPlainTextEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QTableView\n"
"{background-color: #fffff;\n"
"background-color: rgb(255, 255, 255);\n"
"}\n"
"QplainTextEdit\n"
"{\n"
"background-color:(255,255,255,255);\n"
"}"));
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        trinomclient = new QPushButton(tab_6);
        trinomclient->setObjectName(QStringLiteral("trinomclient"));
        trinomclient->setGeometry(QRect(500, 70, 81, 21));
        groupBox_emplye_5 = new QGroupBox(tab_6);
        groupBox_emplye_5->setObjectName(QStringLiteral("groupBox_emplye_5"));
        groupBox_emplye_5->setGeometry(QRect(120, 260, 731, 141));
        groupBox_emplye_5->setStyleSheet(QLatin1String("*{\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QComboBox{\n"
"\n"
"background-color:#405361;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"color: white;\n"
"}"));
        label_47 = new QLabel(groupBox_emplye_5);
        label_47->setObjectName(QStringLiteral("label_47"));
        label_47->setGeometry(QRect(50, 60, 47, 14));
        label_48 = new QLabel(groupBox_emplye_5);
        label_48->setObjectName(QStringLiteral("label_48"));
        label_48->setGeometry(QRect(50, 100, 81, 16));
        label_49 = new QLabel(groupBox_emplye_5);
        label_49->setObjectName(QStringLiteral("label_49"));
        label_49->setGeometry(QRect(396, 30, 71, 20));
        label_50 = new QLabel(groupBox_emplye_5);
        label_50->setObjectName(QStringLiteral("label_50"));
        label_50->setGeometry(QRect(406, 80, 61, 20));
        linenom = new QLineEdit(groupBox_emplye_5);
        linenom->setObjectName(QStringLiteral("linenom"));
        linenom->setGeometry(QRect(160, 60, 113, 20));
        lineEdit_prenom = new QLineEdit(groupBox_emplye_5);
        lineEdit_prenom->setObjectName(QStringLiteral("lineEdit_prenom"));
        lineEdit_prenom->setGeometry(QRect(160, 100, 113, 20));
        lineEdit_email = new QLineEdit(groupBox_emplye_5);
        lineEdit_email->setObjectName(QStringLiteral("lineEdit_email"));
        lineEdit_email->setGeometry(QRect(490, 80, 113, 20));
        label_51 = new QLabel(groupBox_emplye_5);
        label_51->setObjectName(QStringLiteral("label_51"));
        label_51->setGeometry(QRect(50, 30, 47, 14));
        lineEditID = new QLineEdit(groupBox_emplye_5);
        lineEditID->setObjectName(QStringLiteral("lineEditID"));
        lineEditID->setGeometry(QRect(160, 20, 113, 20));
        lineEdit_ad = new QComboBox(groupBox_emplye_5);
        lineEdit_ad->setObjectName(QStringLiteral("lineEdit_ad"));
        lineEdit_ad->setGeometry(QRect(490, 30, 111, 22));
        label_13 = new QLabel(groupBox_emplye_5);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(350, 110, 141, 20));
        label_14 = new QLabel(groupBox_emplye_5);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(510, 110, 71, 16));
        frame_16 = new QFrame(groupBox_emplye_5);
        frame_16->setObjectName(QStringLiteral("frame_16"));
        frame_16->setGeometry(QRect(-10, 0, 791, 141));
        frame_16->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.jpg)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QComboBox{\n"
"\n"
"background-color:#405361;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"color: white;\n"
"}"));
        frame_16->setFrameShape(QFrame::StyledPanel);
        frame_16->setFrameShadow(QFrame::Raised);
        frame_16->raise();
        label_47->raise();
        label_48->raise();
        label_49->raise();
        label_50->raise();
        linenom->raise();
        lineEdit_prenom->raise();
        lineEdit_email->raise();
        label_51->raise();
        lineEditID->raise();
        lineEdit_ad->raise();
        label_13->raise();
        label_14->raise();
        supprimerclient = new QPushButton(tab_6);
        supprimerclient->setObjectName(QStringLiteral("supprimerclient"));
        supprimerclient->setGeometry(QRect(660, 420, 161, 23));
        ajouterclient = new QPushButton(tab_6);
        ajouterclient->setObjectName(QStringLiteral("ajouterclient"));
        ajouterclient->setGeometry(QRect(120, 420, 141, 23));
        ajouterclient->setStyleSheet(QStringLiteral(""));
        modifierclient = new QPushButton(tab_6);
        modifierclient->setObjectName(QStringLiteral("modifierclient"));
        modifierclient->setGeometry(QRect(280, 420, 151, 23));
        triprenomclient = new QPushButton(tab_6);
        triprenomclient->setObjectName(QStringLiteral("triprenomclient"));
        triprenomclient->setGeometry(QRect(590, 70, 91, 21));
        tri_idclient = new QPushButton(tab_6);
        tri_idclient->setObjectName(QStringLiteral("tri_idclient"));
        tri_idclient->setGeometry(QRect(420, 70, 61, 21));
        rechercher = new QLineEdit(tab_6);
        rechercher->setObjectName(QStringLiteral("rechercher"));
        rechercher->setGeometry(QRect(700, 70, 151, 24));
        rechercher->setClearButtonEnabled(true);
        afficherclient = new QPushButton(tab_6);
        afficherclient->setObjectName(QStringLiteral("afficherclient"));
        afficherclient->setGeometry(QRect(460, 420, 151, 23));
        afficherclient->setStyleSheet(QStringLiteral(""));
        statistiqueclient = new QPushButton(tab_6);
        statistiqueclient->setObjectName(QStringLiteral("statistiqueclient"));
        statistiqueclient->setGeometry(QRect(250, 70, 111, 23));
        export_excel = new QPushButton(tab_6);
        export_excel->setObjectName(QStringLiteral("export_excel"));
        export_excel->setGeometry(QRect(140, 70, 101, 23));
        label_37 = new QLabel(tab_6);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setGeometry(QRect(10, 20, 101, 121));
        label_37->setPixmap(QPixmap(QString::fromUtf8(":/logo/logo1.png")));
        frame_12 = new QFrame(tab_6);
        frame_12->setObjectName(QStringLiteral("frame_12"));
        frame_12->setGeometry(QRect(-60, -40, 1091, 741));
        frame_12->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QTableView\n"
"{background-color: #fffff;\n"
"background-color: rgb(255, 255, 255);\n"
"}"));
        frame_12->setFrameShape(QFrame::StyledPanel);
        frame_12->setFrameShadow(QFrame::Raised);
        qrcodeLabel_2 = new QLabel(frame_12);
        qrcodeLabel_2->setObjectName(QStringLiteral("qrcodeLabel_2"));
        qrcodeLabel_2->setGeometry(QRect(260, 380, 401, 211));
        tableau = new QTableView(frame_12);
        tableau->setObjectName(QStringLiteral("tableau"));
        tableau->setGeometry(QRect(220, 150, 631, 131));
        tableau->setStyleSheet(QLatin1String("QTableView{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/download.png)\n"
"}"));
        pushButton = new QPushButton(frame_12);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(44, 280, 101, 23));
        tabWidget_2->addTab(tab_6, QString());
        frame_12->raise();
        statistiqueclient->raise();
        trinomclient->raise();
        groupBox_emplye_5->raise();
        supprimerclient->raise();
        ajouterclient->raise();
        modifierclient->raise();
        triprenomclient->raise();
        tri_idclient->raise();
        rechercher->raise();
        afficherclient->raise();
        export_excel->raise();
        label_37->raise();
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        label_12 = new QLabel(tab_5);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(220, 150, 71, 16));
        port = new QLineEdit(tab_5);
        port->setObjectName(QStringLiteral("port"));
        port->setGeometry(QRect(320, 120, 221, 20));
        paswd = new QLineEdit(tab_5);
        paswd->setObjectName(QStringLiteral("paswd"));
        paswd->setGeometry(QRect(320, 180, 221, 20));
        paswd->setEchoMode(QLineEdit::Password);
        label_10 = new QLabel(tab_5);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(220, 280, 71, 16));
        label_7 = new QLabel(tab_5);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(200, 180, 101, 16));
        sendBtn = new QPushButton(tab_5);
        sendBtn->setObjectName(QStringLiteral("sendBtn"));
        sendBtn->setGeometry(QRect(330, 360, 75, 23));
        rcpt = new QLineEdit(tab_5);
        rcpt->setObjectName(QStringLiteral("rcpt"));
        rcpt->setGeometry(QRect(320, 210, 221, 20));
        label_6 = new QLabel(tab_5);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(230, 120, 47, 13));
        exitBtn = new QPushButton(tab_5);
        exitBtn->setObjectName(QStringLiteral("exitBtn"));
        exitBtn->setGeometry(QRect(420, 360, 75, 23));
        label_9 = new QLabel(tab_5);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(210, 90, 91, 16));
        uname = new QLineEdit(tab_5);
        uname->setObjectName(QStringLiteral("uname"));
        uname->setGeometry(QRect(320, 150, 221, 20));
        label_11 = new QLabel(tab_5);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(230, 240, 47, 13));
        subject = new QLineEdit(tab_5);
        subject->setObjectName(QStringLiteral("subject"));
        subject->setGeometry(QRect(320, 240, 221, 20));
        server = new QLineEdit(tab_5);
        server->setObjectName(QStringLiteral("server"));
        server->setGeometry(QRect(320, 90, 221, 20));
        label_8 = new QLabel(tab_5);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(230, 210, 91, 16));
        label_38 = new QLabel(tab_5);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setGeometry(QRect(40, 10, 101, 121));
        label_38->setPixmap(QPixmap(QString::fromUtf8(":/logo/logo1.png")));
        frame_17 = new QFrame(tab_5);
        frame_17->setObjectName(QStringLiteral("frame_17"));
        frame_17->setGeometry(QRect(-60, -30, 1071, 601));
        frame_17->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QPlainTextEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QplainTextEdit\n"
"{\n"
"background-color:(255,255,255,255);\n"
"}"));
        frame_17->setFrameShape(QFrame::StyledPanel);
        frame_17->setFrameShadow(QFrame::Raised);
        msg = new QPlainTextEdit(tab_5);
        msg->setObjectName(QStringLiteral("msg"));
        msg->setGeometry(QRect(320, 280, 221, 71));
        msg->setStyleSheet(QLatin1String("QPlainTextEdit{\n"
"\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/download.png)\n"
"}"));
        tabWidget_2->addTab(tab_5, QString());
        frame_17->raise();
        label_12->raise();
        port->raise();
        paswd->raise();
        label_10->raise();
        label_7->raise();
        sendBtn->raise();
        rcpt->raise();
        label_6->raise();
        exitBtn->raise();
        label_9->raise();
        uname->raise();
        label_11->raise();
        subject->raise();
        server->raise();
        label_8->raise();
        label_38->raise();
        msg->raise();
        tabWidget->addTab(tab_client, QString());
        tab_agence = new QWidget();
        tab_agence->setObjectName(QStringLiteral("tab_agence"));
        pushButton_supprimer = new QPushButton(tab_agence);
        pushButton_supprimer->setObjectName(QStringLiteral("pushButton_supprimer"));
        pushButton_supprimer->setGeometry(QRect(790, 430, 91, 23));
        label = new QLabel(tab_agence);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(530, 430, 121, 20));
        pushButton_imprimer = new QPushButton(tab_agence);
        pushButton_imprimer->setObjectName(QStringLiteral("pushButton_imprimer"));
        pushButton_imprimer->setGeometry(QRect(224, 92, 121, 31));
        pushButton_imprimer->setStyleSheet(QStringLiteral(""));
        lineEdit_recherche = new QLineEdit(tab_agence);
        lineEdit_recherche->setObjectName(QStringLiteral("lineEdit_recherche"));
        lineEdit_recherche->setGeometry(QRect(750, 100, 151, 20));
        lineEdit_recherche->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(0, 0, 0);"));
        pushButton_ajouter = new QPushButton(tab_agence);
        pushButton_ajouter->setObjectName(QStringLiteral("pushButton_ajouter"));
        pushButton_ajouter->setGeometry(QRect(190, 430, 91, 23));
        pushButton_ajouter->setStyleSheet(QStringLiteral("color: rgb(0, 0, 0);"));
        groupBox_emplye = new QGroupBox(tab_agence);
        groupBox_emplye->setObjectName(QStringLiteral("groupBox_emplye"));
        groupBox_emplye->setGeometry(QRect(120, 270, 731, 141));
        groupBox_emplye->setStyleSheet(QStringLiteral(""));
        label_1 = new QLabel(groupBox_emplye);
        label_1->setObjectName(QStringLiteral("label_1"));
        label_1->setGeometry(QRect(10, 30, 121, 20));
        label_2 = new QLabel(groupBox_emplye);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(26, 100, 71, 20));
        label_3 = new QLabel(groupBox_emplye);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(390, 30, 71, 20));
        lineEdit_id = new QLineEdit(groupBox_emplye);
        lineEdit_id->setObjectName(QStringLiteral("lineEdit_id"));
        lineEdit_id->setGeometry(QRect(160, 30, 113, 20));
        lineEdit_id->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        lineEdit_budget = new QLineEdit(groupBox_emplye);
        lineEdit_budget->setObjectName(QStringLiteral("lineEdit_budget"));
        lineEdit_budget->setGeometry(QRect(500, 30, 113, 20));
        lineEdit_budget->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        label_4 = new QLabel(groupBox_emplye);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(316, 100, 151, 20));
        lineEdit_nbr_employe = new QLineEdit(groupBox_emplye);
        lineEdit_nbr_employe->setObjectName(QStringLiteral("lineEdit_nbr_employe"));
        lineEdit_nbr_employe->setGeometry(QRect(500, 100, 113, 20));
        lineEdit_nbr_employe->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        comboBox_adresse = new QComboBox(groupBox_emplye);
        comboBox_adresse->setObjectName(QStringLiteral("comboBox_adresse"));
        comboBox_adresse->setGeometry(QRect(160, 100, 111, 22));
        comboBox_adresse->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(0, 170, 0);"));
        frame_15 = new QFrame(groupBox_emplye);
        frame_15->setObjectName(QStringLiteral("frame_15"));
        frame_15->setGeometry(QRect(-20, 0, 791, 141));
        frame_15->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.jpg)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QComboBox{\n"
"\n"
"background-color:#405361;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"color: white;\n"
"}"));
        frame_15->setFrameShape(QFrame::StyledPanel);
        frame_15->setFrameShadow(QFrame::Raised);
        frame_15->raise();
        label_1->raise();
        label_2->raise();
        label_3->raise();
        lineEdit_id->raise();
        lineEdit_budget->raise();
        label_4->raise();
        lineEdit_nbr_employe->raise();
        comboBox_adresse->raise();
        pushButton_tri_id = new QPushButton(tab_agence);
        pushButton_tri_id->setObjectName(QStringLiteral("pushButton_tri_id"));
        pushButton_tri_id->setGeometry(QRect(810, 140, 81, 51));
        pushButton_tri_id->setStyleSheet(QStringLiteral(""));
        pushButton_modifier = new QPushButton(tab_agence);
        pushButton_modifier->setObjectName(QStringLiteral("pushButton_modifier"));
        pushButton_modifier->setGeometry(QRect(394, 430, 101, 23));
        pushButton_tri_budget = new QPushButton(tab_agence);
        pushButton_tri_budget->setObjectName(QStringLiteral("pushButton_tri_budget"));
        pushButton_tri_budget->setGeometry(QRect(810, 200, 81, 51));
        pushButton_tri_budget->setStyleSheet(QStringLiteral(""));
        pushButton_tri_nbr_employe = new QPushButton(tab_agence);
        pushButton_tri_nbr_employe->setObjectName(QStringLiteral("pushButton_tri_nbr_employe"));
        pushButton_tri_nbr_employe->setGeometry(QRect(50, 200, 111, 51));
        pushButton_tri_nbr_employe->setStyleSheet(QStringLiteral(""));
        pushButton_tri_nbr_client = new QPushButton(tab_agence);
        pushButton_tri_nbr_client->setObjectName(QStringLiteral("pushButton_tri_nbr_client"));
        pushButton_tri_nbr_client->setGeometry(QRect(50, 140, 111, 51));
        pushButton_tri_nbr_client->setStyleSheet(QStringLiteral(""));
        pushButton_statistique = new QPushButton(tab_agence);
        pushButton_statistique->setObjectName(QStringLiteral("pushButton_statistique"));
        pushButton_statistique->setGeometry(QRect(450, 92, 121, 31));
        pushButton_statistique->setStyleSheet(QStringLiteral(""));
        lineEdit_supprimer = new QLineEdit(tab_agence);
        lineEdit_supprimer->setObjectName(QStringLiteral("lineEdit_supprimer"));
        lineEdit_supprimer->setGeometry(QRect(660, 430, 113, 20));
        tableView = new QTableView(tab_agence);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(170, 130, 631, 131));
        tableView->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(0, 0, 0);"));
        label_5 = new QLabel(tab_agence);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(640, 100, 91, 20));
        label_36 = new QLabel(tab_agence);
        label_36->setObjectName(QStringLiteral("label_36"));
        label_36->setGeometry(QRect(20, 10, 101, 121));
        label_36->setPixmap(QPixmap(QString::fromUtf8(":/logo/logo1.png")));
        frame_13 = new QFrame(tab_agence);
        frame_13->setObjectName(QStringLiteral("frame_13"));
        frame_13->setGeometry(QRect(0, 0, 1071, 681));
        frame_13->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_13->setFrameShape(QFrame::StyledPanel);
        frame_13->setFrameShadow(QFrame::Raised);
        tabWidget->addTab(tab_agence, QString());
        frame_13->raise();
        pushButton_supprimer->raise();
        label->raise();
        pushButton_imprimer->raise();
        lineEdit_recherche->raise();
        pushButton_ajouter->raise();
        groupBox_emplye->raise();
        pushButton_tri_id->raise();
        pushButton_modifier->raise();
        pushButton_tri_budget->raise();
        pushButton_tri_nbr_employe->raise();
        pushButton_tri_nbr_client->raise();
        pushButton_statistique->raise();
        lineEdit_supprimer->raise();
        tableView->raise();
        label_5->raise();
        label_36->raise();
        tab_bien = new QWidget();
        tab_bien->setObjectName(QStringLiteral("tab_bien"));
        label_41 = new QLabel(tab_bien);
        label_41->setObjectName(QStringLiteral("label_41"));
        label_41->setGeometry(QRect(30, 20, 101, 121));
        label_41->setPixmap(QPixmap(QString::fromUtf8(":/logo/logo1.png")));
        frame_18 = new QFrame(tab_bien);
        frame_18->setObjectName(QStringLiteral("frame_18"));
        frame_18->setGeometry(QRect(-20, 0, 1071, 671));
        frame_18->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QTableView\n"
"{\n"
"background-color: rbga(255, 255, 255);\n"
"}\n"
"QComboBox{\n"
"\n"
"background-color:#405361;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"color: white;\n"
"}"));
        frame_18->setFrameShape(QFrame::StyledPanel);
        frame_18->setFrameShadow(QFrame::Raised);
        id_supp_2 = new QLineEdit(frame_18);
        id_supp_2->setObjectName(QStringLiteral("id_supp_2"));
        id_supp_2->setGeometry(QRect(340, 450, 113, 20));
        comboBox = new QComboBox(frame_18);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(430, 90, 111, 22));
        ajouter_bien = new QPushButton(frame_18);
        ajouter_bien->setObjectName(QStringLiteral("ajouter_bien"));
        ajouter_bien->setGeometry(QRect(770, 450, 75, 23));
        actualiser = new QPushButton(frame_18);
        actualiser->setObjectName(QStringLiteral("actualiser"));
        actualiser->setGeometry(QRect(654, 450, 101, 23));
        tabWidget_5 = new QTabWidget(frame_18);
        tabWidget_5->setObjectName(QStringLiteral("tabWidget_5"));
        tabWidget_5->setGeometry(QRect(180, 280, 731, 141));
        tabWidget_5->setStyleSheet(QLatin1String("QComboBox{\n"
"\n"
"background-color:#405361;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"color: white;\n"
"}"));
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        label_44 = new QLabel(tab_4);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setGeometry(QRect(54, 10, 47, 14));
        id_2 = new QLineEdit(tab_4);
        id_2->setObjectName(QStringLiteral("id_2"));
        id_2->setGeometry(QRect(114, 10, 113, 20));
        label_45 = new QLabel(tab_4);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setGeometry(QRect(410, 60, 71, 16));
        label_46 = new QLabel(tab_4);
        label_46->setObjectName(QStringLiteral("label_46"));
        label_46->setGeometry(QRect(54, 80, 47, 14));
        label_52 = new QLabel(tab_4);
        label_52->setObjectName(QStringLiteral("label_52"));
        label_52->setGeometry(QRect(400, 20, 71, 16));
        label_53 = new QLabel(tab_4);
        label_53->setObjectName(QStringLiteral("label_53"));
        label_53->setGeometry(QRect(20, 40, 91, 20));
        prix_2 = new QLineEdit(tab_4);
        prix_2->setObjectName(QStringLiteral("prix_2"));
        prix_2->setGeometry(QRect(110, 80, 113, 20));
        categorie_2 = new QLineEdit(tab_4);
        categorie_2->setObjectName(QStringLiteral("categorie_2"));
        categorie_2->setGeometry(QRect(110, 40, 113, 20));
        adresse_2 = new QLineEdit(tab_4);
        adresse_2->setObjectName(QStringLiteral("adresse_2"));
        adresse_2->setGeometry(QRect(480, 20, 113, 20));
        statu = new QComboBox(tab_4);
        statu->setObjectName(QStringLiteral("statu"));
        statu->setGeometry(QRect(490, 60, 111, 22));
        frame_19 = new QFrame(tab_4);
        frame_19->setObjectName(QStringLiteral("frame_19"));
        frame_19->setGeometry(QRect(-20, -20, 791, 141));
        frame_19->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.jpg)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_19->setFrameShape(QFrame::StyledPanel);
        frame_19->setFrameShadow(QFrame::Raised);
        tabWidget_5->addTab(tab_4, QString());
        frame_19->raise();
        label_44->raise();
        id_2->raise();
        label_45->raise();
        label_46->raise();
        label_52->raise();
        label_53->raise();
        prix_2->raise();
        categorie_2->raise();
        adresse_2->raise();
        statu->raise();
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        label_54 = new QLabel(tab_7);
        label_54->setObjectName(QStringLiteral("label_54"));
        label_54->setGeometry(QRect(40, 10, 47, 14));
        id_modif_2 = new QLineEdit(tab_7);
        id_modif_2->setObjectName(QStringLiteral("id_modif_2"));
        id_modif_2->setGeometry(QRect(80, 10, 113, 20));
        label_55 = new QLabel(tab_7);
        label_55->setObjectName(QStringLiteral("label_55"));
        label_55->setGeometry(QRect(10, 40, 61, 20));
        catg_modif2 = new QLineEdit(tab_7);
        catg_modif2->setObjectName(QStringLiteral("catg_modif2"));
        catg_modif2->setGeometry(QRect(80, 40, 113, 20));
        label_56 = new QLabel(tab_7);
        label_56->setObjectName(QStringLiteral("label_56"));
        label_56->setGeometry(QRect(30, 80, 47, 14));
        prix_modif2 = new QLineEdit(tab_7);
        prix_modif2->setObjectName(QStringLiteral("prix_modif2"));
        prix_modif2->setGeometry(QRect(80, 70, 113, 20));
        label_57 = new QLabel(tab_7);
        label_57->setObjectName(QStringLiteral("label_57"));
        label_57->setGeometry(QRect(250, 10, 81, 16));
        adresse_modif_2 = new QLineEdit(tab_7);
        adresse_modif_2->setObjectName(QStringLiteral("adresse_modif_2"));
        adresse_modif_2->setGeometry(QRect(330, 10, 113, 20));
        label_58 = new QLabel(tab_7);
        label_58->setObjectName(QStringLiteral("label_58"));
        label_58->setGeometry(QRect(270, 50, 47, 14));
        modifier_bien = new QPushButton(tab_7);
        modifier_bien->setObjectName(QStringLiteral("modifier_bien"));
        modifier_bien->setGeometry(QRect(500, 30, 75, 23));
        satut_modif = new QComboBox(tab_7);
        satut_modif->setObjectName(QStringLiteral("satut_modif"));
        satut_modif->setGeometry(QRect(330, 50, 111, 22));
        frame_20 = new QFrame(tab_7);
        frame_20->setObjectName(QStringLiteral("frame_20"));
        frame_20->setGeometry(QRect(-30, -10, 791, 141));
        frame_20->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.jpg)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_20->setFrameShape(QFrame::StyledPanel);
        frame_20->setFrameShadow(QFrame::Raised);
        tabWidget_5->addTab(tab_7, QString());
        frame_20->raise();
        label_54->raise();
        id_modif_2->raise();
        label_55->raise();
        catg_modif2->raise();
        label_56->raise();
        prix_modif2->raise();
        label_57->raise();
        adresse_modif_2->raise();
        label_58->raise();
        modifier_bien->raise();
        satut_modif->raise();
        tab_9 = new QWidget();
        tab_9->setObjectName(QStringLiteral("tab_9"));
        frame_22 = new QFrame(tab_9);
        frame_22->setObjectName(QStringLiteral("frame_22"));
        frame_22->setGeometry(QRect(0, 0, 791, 141));
        frame_22->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.jpg)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_22->setFrameShape(QFrame::StyledPanel);
        frame_22->setFrameShadow(QFrame::Raised);
        ouvrir = new QPushButton(frame_22);
        ouvrir->setObjectName(QStringLiteral("ouvrir"));
        ouvrir->setGeometry(QRect(70, 20, 75, 23));
        Fermer = new QPushButton(frame_22);
        Fermer->setObjectName(QStringLiteral("Fermer"));
        Fermer->setGeometry(QRect(70, 70, 75, 21));
        label_59 = new QLabel(frame_22);
        label_59->setObjectName(QStringLiteral("label_59"));
        label_59->setGeometry(QRect(176, 50, 61, 20));
        label_60 = new QLabel(frame_22);
        label_60->setObjectName(QStringLiteral("label_60"));
        label_60->setGeometry(QRect(290, 50, 47, 14));
        tabWidget_5->addTab(tab_9, QString());
        statistique_bien = new QPushButton(frame_18);
        statistique_bien->setObjectName(QStringLiteral("statistique_bien"));
        statistique_bien->setGeometry(QRect(560, 90, 91, 23));
        rechercher_bien = new QLineEdit(frame_18);
        rechercher_bien->setObjectName(QStringLiteral("rechercher_bien"));
        rechercher_bien->setGeometry(QRect(220, 90, 181, 20));
        supprimer_bien = new QPushButton(frame_18);
        supprimer_bien->setObjectName(QStringLiteral("supprimer_bien"));
        supprimer_bien->setGeometry(QRect(214, 450, 101, 23));
        error = new QLabel(frame_18);
        error->setObjectName(QStringLiteral("error"));
        error->setGeometry(QRect(480, 450, 151, 20));
        label_16 = new QLabel(frame_18);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(850, 70, 161, 51));
        label_15 = new QLabel(frame_18);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(670, 70, 161, 51));
        tab_bien_2 = new QTableView(tab_bien);
        tab_bien_2->setObjectName(QStringLiteral("tab_bien_2"));
        tab_bien_2->setGeometry(QRect(160, 150, 731, 121));
        tab_bien_2->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        tabWidget->addTab(tab_bien, QString());
        frame_18->raise();
        label_41->raise();
        tab_bien_2->raise();
        tab_reclamation = new QWidget();
        tab_reclamation->setObjectName(QStringLiteral("tab_reclamation"));
        label_42 = new QLabel(tab_reclamation);
        label_42->setObjectName(QStringLiteral("label_42"));
        label_42->setGeometry(QRect(20, 20, 101, 121));
        label_42->setPixmap(QPixmap(QString::fromUtf8(":/logo/logo1.png")));
        rechercher_rec = new QLineEdit(tab_reclamation);
        rechercher_rec->setObjectName(QStringLiteral("rechercher_rec"));
        rechercher_rec->setGeometry(QRect(710, 130, 191, 24));
        rechercher_rec->setClearButtonEnabled(true);
        groupBox_emplye_2 = new QGroupBox(tab_reclamation);
        groupBox_emplye_2->setObjectName(QStringLiteral("groupBox_emplye_2"));
        groupBox_emplye_2->setGeometry(QRect(160, 300, 731, 141));
        groupBox_emplye_2->setStyleSheet(QStringLiteral("color: white;"));
        label_71 = new QLabel(groupBox_emplye_2);
        label_71->setObjectName(QStringLiteral("label_71"));
        label_71->setGeometry(QRect(180, 20, 47, 14));
        label_72 = new QLabel(groupBox_emplye_2);
        label_72->setObjectName(QStringLiteral("label_72"));
        label_72->setGeometry(QRect(20, 50, 71, 16));
        label_73 = new QLabel(groupBox_emplye_2);
        label_73->setObjectName(QStringLiteral("label_73"));
        label_73->setGeometry(QRect(380, 20, 47, 14));
        label_74 = new QLabel(groupBox_emplye_2);
        label_74->setObjectName(QStringLiteral("label_74"));
        label_74->setGeometry(QRect(540, 20, 47, 14));
        lientype = new QLineEdit(groupBox_emplye_2);
        lientype->setObjectName(QStringLiteral("lientype"));
        lientype->setGeometry(QRect(240, 20, 113, 20));
        lineEdit_description = new QLineEdit(groupBox_emplye_2);
        lineEdit_description->setObjectName(QStringLiteral("lineEdit_description"));
        lineEdit_description->setGeometry(QRect(20, 70, 701, 61));
        lineEdit_titre = new QLineEdit(groupBox_emplye_2);
        lineEdit_titre->setObjectName(QStringLiteral("lineEdit_titre"));
        lineEdit_titre->setGeometry(QRect(580, 20, 113, 20));
        label_75 = new QLabel(groupBox_emplye_2);
        label_75->setObjectName(QStringLiteral("label_75"));
        label_75->setGeometry(QRect(20, 20, 47, 14));
        lineEditIDreclamation = new QLineEdit(groupBox_emplye_2);
        lineEditIDreclamation->setObjectName(QStringLiteral("lineEditIDreclamation"));
        lineEditIDreclamation->setGeometry(QRect(60, 20, 113, 20));
        lineEdit_date = new QLineEdit(groupBox_emplye_2);
        lineEdit_date->setObjectName(QStringLiteral("lineEdit_date"));
        lineEdit_date->setGeometry(QRect(410, 20, 113, 20));
        frame_24 = new QFrame(groupBox_emplye_2);
        frame_24->setObjectName(QStringLiteral("frame_24"));
        frame_24->setGeometry(QRect(-30, -10, 791, 161));
        frame_24->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.jpg)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}\n"
"QComboBox{\n"
"\n"
"background-color:#405361;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"color: white;\n"
"}"));
        frame_24->setFrameShape(QFrame::StyledPanel);
        frame_24->setFrameShadow(QFrame::Raised);
        frame_24->raise();
        label_71->raise();
        label_72->raise();
        label_73->raise();
        label_74->raise();
        lientype->raise();
        lineEdit_description->raise();
        lineEdit_titre->raise();
        label_75->raise();
        lineEditIDreclamation->raise();
        lineEdit_date->raise();
        tableaurec = new QTableView(tab_reclamation);
        tableaurec->setObjectName(QStringLiteral("tableaurec"));
        tableaurec->setGeometry(QRect(160, 170, 731, 121));
        tableaurec->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        tableaurec->setSortingEnabled(true);
        tableaurec->horizontalHeader()->setCascadingSectionResizes(true);
        tableaurec->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        tableaurec->horizontalHeader()->setStretchLastSection(false);
        label_61 = new QLabel(tab_reclamation);
        label_61->setObjectName(QStringLiteral("label_61"));
        label_61->setGeometry(QRect(440, 130, 47, 14));
        pushButton_ajouter_2 = new QPushButton(tab_reclamation);
        pushButton_ajouter_2->setObjectName(QStringLiteral("pushButton_ajouter_2"));
        pushButton_ajouter_2->setGeometry(QRect(100, 450, 161, 23));
        pushButton_ajouter_2->setStyleSheet(QStringLiteral(""));
        pushButton_ajouter_3 = new QPushButton(tab_reclamation);
        pushButton_ajouter_3->setObjectName(QStringLiteral("pushButton_ajouter_3"));
        pushButton_ajouter_3->setGeometry(QRect(470, 450, 181, 23));
        pushButton_ajouter_3->setStyleSheet(QStringLiteral(""));
        chatbot = new QPushButton(tab_reclamation);
        chatbot->setObjectName(QStringLiteral("chatbot"));
        chatbot->setGeometry(QRect(260, 130, 141, 23));
        pushButton_7 = new QPushButton(tab_reclamation);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(650, 130, 51, 21));
        pushButton_merier1_3 = new QPushButton(tab_reclamation);
        pushButton_merier1_3->setObjectName(QStringLiteral("pushButton_merier1_3"));
        pushButton_merier1_3->setGeometry(QRect(160, 130, 75, 23));
        pushButton_supprimer_2 = new QPushButton(tab_reclamation);
        pushButton_supprimer_2->setObjectName(QStringLiteral("pushButton_supprimer_2"));
        pushButton_supprimer_2->setGeometry(QRect(700, 450, 231, 23));
        pushButton_merier1_2 = new QPushButton(tab_reclamation);
        pushButton_merier1_2->setObjectName(QStringLiteral("pushButton_merier1_2"));
        pushButton_merier1_2->setGeometry(QRect(544, 130, 101, 23));
        frame_21 = new QFrame(tab_reclamation);
        frame_21->setObjectName(QStringLiteral("frame_21"));
        frame_21->setGeometry(QRect(0, -30, 1071, 681));
        frame_21->setStyleSheet(QLatin1String("*{background:rgb(255,255,255);\n"
"font-size:15px;\n"
"font-family:Century Gothic, sans-serif;\n"
"}\n"
"QFrame{\n"
"border:solid 10px rgba(0,0,0);\n"
"background-image:url(:/bg/bg.png)\n"
"}\n"
"QLineEdit{\n"
"		color:#8d98a1;\n"
"		background-color:#405361;\n"
"front-size:18px;\n"
"border-style: outset;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton{\n"
"background:#ced1d8;\n"
"border-style: oustet;\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color:rgb(224,0,0);\n"
"border-style: inset;\n"
"}\n"
"QLabel{\n"
"background:rbga(85,170,255,0);\n"
"color: white;\n"
"}"));
        frame_21->setFrameShape(QFrame::StyledPanel);
        frame_21->setFrameShadow(QFrame::Raised);
        pushButton_modifier_2 = new QPushButton(frame_21);
        pushButton_modifier_2->setObjectName(QStringLiteral("pushButton_modifier_2"));
        pushButton_modifier_2->setGeometry(QRect(280, 480, 181, 23));
        tabWidget->addTab(tab_reclamation, QString());
        frame_21->raise();
        label_42->raise();
        rechercher_rec->raise();
        groupBox_emplye_2->raise();
        tableaurec->raise();
        label_61->raise();
        pushButton_ajouter_2->raise();
        pushButton_ajouter_3->raise();
        chatbot->raise();
        pushButton_7->raise();
        pushButton_merier1_3->raise();
        pushButton_supprimer_2->raise();
        pushButton_merier1_2->raise();
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1080, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(4);
        stackedWidget->setCurrentIndex(1);
        tabWidget_3->setCurrentIndex(0);
        tabWidget_4->setCurrentIndex(0);
        tabWidget_2->setCurrentIndex(0);
        tabWidget_5->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        tabWidget->setToolTip(QString());
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        tabWidget->setWhatsThis(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", Q_NULLPTR));
#endif // QT_NO_WHATSTHIS
        qrCode->setText(QString());
        stat_salaire_emp->setText(QApplication::translate("MainWindow", "stat salaire", Q_NULLPTR));
        rechercher_emp->setPlaceholderText(QApplication::translate("MainWindow", "Recherche", Q_NULLPTR));
        tri_salaireemp->setText(QApplication::translate("MainWindow", "TRI SALAIRE", Q_NULLPTR));
        pdfemp->setText(QApplication::translate("MainWindow", "fichier pdf", Q_NULLPTR));
        afficher_employer->setText(QApplication::translate("MainWindow", "Afficher", Q_NULLPTR));
        tri_id_emp->setText(QApplication::translate("MainWindow", "TRI ID", Q_NULLPTR));
        tri_nom_emp->setText(QApplication::translate("MainWindow", "TRI NOM", Q_NULLPTR));
        ajouteremployer->setText(QApplication::translate("MainWindow", "Ajouter", Q_NULLPTR));
        statistique_employer->setText(QApplication::translate("MainWindow", "Statistique", Q_NULLPTR));
        supprimer_employer->setText(QApplication::translate("MainWindow", "Supprimer", Q_NULLPTR));
        label_40->setText(QString());
        label_43->setText(QString());
        qrcodeLabel->setText(QString());
        label_155->setText(QApplication::translate("MainWindow", "Pr\303\251nom :", Q_NULLPTR));
        label_163->setText(QApplication::translate("MainWindow", "Salaire :", Q_NULLPTR));
        label_17->setText(QApplication::translate("MainWindow", "Agence :", Q_NULLPTR));
        label_18->setText(QApplication::translate("MainWindow", "Nom :", Q_NULLPTR));
        label_19->setText(QApplication::translate("MainWindow", "Email", Q_NULLPTR));
        label_20->setText(QApplication::translate("MainWindow", "ID :", Q_NULLPTR));
        label_21->setText(QApplication::translate("MainWindow", "Adresse :", Q_NULLPTR));
        adresse->clear();
        adresse->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Bizerte", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Tunis", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Nabeul", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Sfax", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Sousse", Q_NULLPTR)
        );
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_3), QApplication::translate("MainWindow", "Ajouter Employ\303\251", Q_NULLPTR));
        modifier_emp->setText(QApplication::translate("MainWindow", "Modifier", Q_NULLPTR));
        label_22->setText(QApplication::translate("MainWindow", "Nom :", Q_NULLPTR));
        label_23->setText(QApplication::translate("MainWindow", "Salaire :", Q_NULLPTR));
        label_24->setText(QApplication::translate("MainWindow", "Email :", Q_NULLPTR));
        label_25->setText(QApplication::translate("MainWindow", "Adresse :", Q_NULLPTR));
        label_26->setText(QApplication::translate("MainWindow", "ID :", Q_NULLPTR));
        label_27->setText(QApplication::translate("MainWindow", "Agence :", Q_NULLPTR));
        label_28->setText(QApplication::translate("MainWindow", "Pr\303\251nom :", Q_NULLPTR));
        adresse_modif->clear();
        adresse_modif->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Bizerte", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Tunis", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Nabeul", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Sfax", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Sousse", Q_NULLPTR)
        );
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_8), QApplication::translate("MainWindow", "Modifier Employ\303\251", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab), QApplication::translate("MainWindow", "CRUD", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("MainWindow", "Authentification", Q_NULLPTR));
        label_29->setText(QApplication::translate("MainWindow", "ID :", Q_NULLPTR));
        label_30->setText(QApplication::translate("MainWindow", "MOT DE PASSE :", Q_NULLPTR));
        label_31->setText(QApplication::translate("MainWindow", "EMAIL :", Q_NULLPTR));
        Supprimer->setText(QApplication::translate("MainWindow", "Supprimer", Q_NULLPTR));
        Modifier->setText(QApplication::translate("MainWindow", "Modifier", Q_NULLPTR));
        Afficher->setText(QApplication::translate("MainWindow", "Afficher", Q_NULLPTR));
        Ajouter->setText(QApplication::translate("MainWindow", "Ajouter", Q_NULLPTR));
        label_39->setText(QString());
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_2), QApplication::translate("MainWindow", "Autehntification", Q_NULLPTR));
        login->setText(QApplication::translate("MainWindow", "LOGIN", Q_NULLPTR));
        email_login->setText(QString());
        email_login->setPlaceholderText(QApplication::translate("MainWindow", "your mail", Q_NULLPTR));
        mdp_login->setPlaceholderText(QApplication::translate("MainWindow", "your mail password", Q_NULLPTR));
        label_32->setText(QApplication::translate("MainWindow", "ImmoClick", Q_NULLPTR));
        label_34->setText(QApplication::translate("MainWindow", "EMAIL :", Q_NULLPTR));
        label_33->setText(QApplication::translate("MainWindow", "Mot de passe", Q_NULLPTR));
        label_35->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_employe), QApplication::translate("MainWindow", "Employ\303\251s", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        tabWidget_2->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        trinomclient->setText(QApplication::translate("MainWindow", "Tri NOM", Q_NULLPTR));
        groupBox_emplye_5->setTitle(QApplication::translate("MainWindow", "Client", Q_NULLPTR));
        label_47->setText(QApplication::translate("MainWindow", "Nom :", Q_NULLPTR));
        label_48->setText(QApplication::translate("MainWindow", "Pr\303\251nom :", Q_NULLPTR));
        label_49->setText(QApplication::translate("MainWindow", "Adresse :", Q_NULLPTR));
        label_50->setText(QApplication::translate("MainWindow", "E-mail", Q_NULLPTR));
        label_51->setText(QApplication::translate("MainWindow", "ID", Q_NULLPTR));
        lineEdit_ad->clear();
        lineEdit_ad->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Bizerte", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Tunis", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Nabeul", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Sfax", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Sousse", Q_NULLPTR)
        );
        label_13->setText(QApplication::translate("MainWindow", "Etat du afficheur", Q_NULLPTR));
        label_14->setText(QString());
        supprimerclient->setText(QApplication::translate("MainWindow", "Supprimer un client", Q_NULLPTR));
        ajouterclient->setText(QApplication::translate("MainWindow", "Ajouter un client", Q_NULLPTR));
        modifierclient->setText(QApplication::translate("MainWindow", "Modifier un client", Q_NULLPTR));
        triprenomclient->setText(QApplication::translate("MainWindow", "Tri PRENOM", Q_NULLPTR));
        tri_idclient->setText(QApplication::translate("MainWindow", "Tri ID", Q_NULLPTR));
        rechercher->setPlaceholderText(QApplication::translate("MainWindow", "Recherche", Q_NULLPTR));
        afficherclient->setText(QApplication::translate("MainWindow", "Afficher les clients", Q_NULLPTR));
        statistiqueclient->setText(QApplication::translate("MainWindow", "Statistique", Q_NULLPTR));
        export_excel->setText(QApplication::translate("MainWindow", "export excel", Q_NULLPTR));
        label_37->setText(QString());
        qrcodeLabel_2->setText(QString());
        pushButton->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_6), QApplication::translate("MainWindow", "CRUD", Q_NULLPTR));
        label_12->setText(QApplication::translate("MainWindow", "Your email", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "Message", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Your password", Q_NULLPTR));
        sendBtn->setText(QApplication::translate("MainWindow", "Envoyer", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "PORT", Q_NULLPTR));
        exitBtn->setText(QApplication::translate("MainWindow", "Annuler", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainWindow", "SMTP server", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "Objet", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Envoyer \303\240", Q_NULLPTR));
        label_38->setText(QString());
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_5), QApplication::translate("MainWindow", "MAIL", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_client), QApplication::translate("MainWindow", "Clients", Q_NULLPTR));
        pushButton_supprimer->setText(QApplication::translate("MainWindow", "Supprimer", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "ID \303\240 supprimer :", Q_NULLPTR));
        pushButton_imprimer->setText(QApplication::translate("MainWindow", "Imprimer", Q_NULLPTR));
        lineEdit_recherche->setText(QString());
        pushButton_ajouter->setText(QApplication::translate("MainWindow", "Ajouter", Q_NULLPTR));
        groupBox_emplye->setTitle(QApplication::translate("MainWindow", "Employ\303\251", Q_NULLPTR));
        label_1->setText(QApplication::translate("MainWindow", "ID de l'agence :", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Adresse :", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Budget :", Q_NULLPTR));
        lineEdit_id->setText(QString());
        label_4->setText(QApplication::translate("MainWindow", "Nombre d'employ\303\251s :", Q_NULLPTR));
        comboBox_adresse->clear();
        comboBox_adresse->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Tunis", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Manouba", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Ben Arouss", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Sousse", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Bizerte", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Nabeul", Q_NULLPTR)
        );
        pushButton_tri_id->setText(QApplication::translate("MainWindow", "ID", Q_NULLPTR));
        pushButton_modifier->setText(QApplication::translate("MainWindow", "Modifier", Q_NULLPTR));
        pushButton_tri_budget->setText(QApplication::translate("MainWindow", "BUDGET", Q_NULLPTR));
        pushButton_tri_nbr_employe->setText(QApplication::translate("MainWindow", "Nbr Employ\303\251", Q_NULLPTR));
        pushButton_tri_nbr_client->setText(QApplication::translate("MainWindow", "Nbr Client", Q_NULLPTR));
        pushButton_statistique->setText(QApplication::translate("MainWindow", "Statistique", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Recherche", Q_NULLPTR));
        label_36->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_agence), QApplication::translate("MainWindow", "Agences", Q_NULLPTR));
        label_41->setText(QString());
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Defaut", Q_NULLPTR)
         << QApplication::translate("MainWindow", "ID", Q_NULLPTR)
         << QApplication::translate("MainWindow", "ADRESSE", Q_NULLPTR)
         << QApplication::translate("MainWindow", "STATUT", Q_NULLPTR)
        );
        ajouter_bien->setText(QApplication::translate("MainWindow", "Ajouter", Q_NULLPTR));
        actualiser->setText(QApplication::translate("MainWindow", "Actualiser", Q_NULLPTR));
        label_44->setText(QApplication::translate("MainWindow", "ID :", Q_NULLPTR));
        label_45->setText(QApplication::translate("MainWindow", "Statut :", Q_NULLPTR));
        label_46->setText(QApplication::translate("MainWindow", "prix :", Q_NULLPTR));
        label_52->setText(QApplication::translate("MainWindow", "Adresse :", Q_NULLPTR));
        label_53->setText(QApplication::translate("MainWindow", "Categorie :", Q_NULLPTR));
        statu->clear();
        statu->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Vendu", Q_NULLPTR)
         << QApplication::translate("MainWindow", "A vendre", Q_NULLPTR)
        );
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_4), QApplication::translate("MainWindow", "Ajouter bien", Q_NULLPTR));
        label_54->setText(QApplication::translate("MainWindow", "ID :", Q_NULLPTR));
        label_55->setText(QApplication::translate("MainWindow", "Categorie :", Q_NULLPTR));
        label_56->setText(QApplication::translate("MainWindow", "prix :", Q_NULLPTR));
        label_57->setText(QApplication::translate("MainWindow", "Adresse :", Q_NULLPTR));
        label_58->setText(QApplication::translate("MainWindow", "Statut :", Q_NULLPTR));
        modifier_bien->setText(QApplication::translate("MainWindow", "Modifier", Q_NULLPTR));
        satut_modif->clear();
        satut_modif->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Vendu", Q_NULLPTR)
         << QApplication::translate("MainWindow", "A vendre", Q_NULLPTR)
        );
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_7), QApplication::translate("MainWindow", "Modifier bien", Q_NULLPTR));
        ouvrir->setText(QApplication::translate("MainWindow", "Ouvrir", Q_NULLPTR));
        Fermer->setText(QApplication::translate("MainWindow", "Fermer", Q_NULLPTR));
        label_59->setText(QApplication::translate("MainWindow", "Bariere", Q_NULLPTR));
        label_60->setText(QApplication::translate("MainWindow", "test", Q_NULLPTR));
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_9), QApplication::translate("MainWindow", "Arduino", Q_NULLPTR));
        statistique_bien->setText(QApplication::translate("MainWindow", "Statistique", Q_NULLPTR));
        supprimer_bien->setText(QApplication::translate("MainWindow", "Supprimer", Q_NULLPTR));
        error->setText(QString());
        label_16->setText(QString());
        label_15->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_bien), QApplication::translate("MainWindow", "Biens", Q_NULLPTR));
        label_42->setText(QString());
        rechercher_rec->setText(QString());
        rechercher_rec->setPlaceholderText(QApplication::translate("MainWindow", "Recherche", Q_NULLPTR));
        groupBox_emplye_2->setTitle(QApplication::translate("MainWindow", "reclmation", Q_NULLPTR));
        label_71->setText(QApplication::translate("MainWindow", "type:", Q_NULLPTR));
        label_72->setText(QApplication::translate("MainWindow", "Description:", Q_NULLPTR));
        label_73->setText(QApplication::translate("MainWindow", "Date:", Q_NULLPTR));
        label_74->setText(QApplication::translate("MainWindow", "Titre:", Q_NULLPTR));
        label_75->setText(QApplication::translate("MainWindow", "ID", Q_NULLPTR));
        label_61->setText(QApplication::translate("MainWindow", "TextLabel", Q_NULLPTR));
        pushButton_ajouter_2->setText(QApplication::translate("MainWindow", "Ajouter reclamation", Q_NULLPTR));
        pushButton_ajouter_3->setText(QApplication::translate("MainWindow", "Afficher les reclamation", Q_NULLPTR));
        chatbot->setText(QApplication::translate("MainWindow", "chat bot", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("MainWindow", "Tri", Q_NULLPTR));
        pushButton_merier1_3->setText(QApplication::translate("MainWindow", "notif", Q_NULLPTR));
        pushButton_supprimer_2->setText(QApplication::translate("MainWindow", "Supprimer une reclamation", Q_NULLPTR));
        pushButton_merier1_2->setText(QApplication::translate("MainWindow", "Statistique", Q_NULLPTR));
        pushButton_modifier_2->setText(QApplication::translate("MainWindow", "Modifier reclamation", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_reclamation), QApplication::translate("MainWindow", "R\303\251clamations", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
