/********************************************************************************
** Form generated from reading UI file 'statistique_age.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTIQUE_AGE_H
#define UI_STATISTIQUE_AGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_statistique_age
{
public:
    QLabel *label_8;
    QLabel *label_4;
    QWidget *widget_5;
    QWidget *widget;
    QWidget *widget_4;
    QWidget *widget_2;
    QWidget *widget_3;
    QLabel *label_2;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label;
    QLabel *label_3;

    void setupUi(QWidget *statistique_age)
    {
        if (statistique_age->objectName().isEmpty())
            statistique_age->setObjectName(QStringLiteral("statistique_age"));
        statistique_age->resize(709, 493);
        label_8 = new QLabel(statistique_age);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(20, 440, 481, 41));
        label_8->setStyleSheet(QLatin1String("font: 18pt \"MS Shell Dlg 2\";\n"
"color: rgb(0, 170, 255);"));
        label_4 = new QLabel(statistique_age);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(570, 140, 131, 16));
        label_4->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        widget_5 = new QWidget(statistique_age);
        widget_5->setObjectName(QStringLiteral("widget_5"));
        widget_5->setGeometry(QRect(540, 100, 20, 20));
        widget_5->setStyleSheet(QStringLiteral("background-color: rgb(0, 255, 0);"));
        widget = new QWidget(statistique_age);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(540, 70, 20, 20));
        widget->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 255);"));
        widget_4 = new QWidget(statistique_age);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        widget_4->setGeometry(QRect(540, 170, 20, 20));
        widget_4->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"background-color: rgb(255, 255, 0);"));
        widget_2 = new QWidget(statistique_age);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(540, 140, 20, 20));
        widget_2->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        widget_3 = new QWidget(statistique_age);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(540, 200, 21, 20));
        widget_3->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"background-color: rgb(255, 0, 0);"));
        label_2 = new QLabel(statistique_age);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(570, 70, 111, 16));
        label_2->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_5 = new QLabel(statistique_age);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(570, 170, 111, 16));
        label_5->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_6 = new QLabel(statistique_age);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(570, 200, 111, 16));
        label_6->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label = new QLabel(statistique_age);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(536, 39, 131, 31));
        label->setStyleSheet(QStringLiteral("font: 75 italic 14pt \"Arial\";"));
        label_3 = new QLabel(statistique_age);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(570, 100, 111, 16));
        label_3->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));

        retranslateUi(statistique_age);

        QMetaObject::connectSlotsByName(statistique_age);
    } // setupUi

    void retranslateUi(QWidget *statistique_age)
    {
        statistique_age->setWindowTitle(QApplication::translate("statistique_age", "Form", Q_NULLPTR));
        label_8->setText(QApplication::translate("statistique_age", "Statistique", Q_NULLPTR));
        label_4->setText(QApplication::translate("statistique_age", "Nabeul", Q_NULLPTR));
        label_2->setText(QApplication::translate("statistique_age", "Bizerte", Q_NULLPTR));
        label_5->setText(QApplication::translate("statistique_age", "Manouba", Q_NULLPTR));
        label_6->setText(QApplication::translate("statistique_age", "Sousse", Q_NULLPTR));
        label->setText(QApplication::translate("statistique_age", "Pourcentage", Q_NULLPTR));
        label_3->setText(QApplication::translate("statistique_age", "Tunis", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class statistique_age: public Ui_statistique_age {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTIQUE_AGE_H
