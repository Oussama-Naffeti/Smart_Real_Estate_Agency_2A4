/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../immoclick/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[71];
    char stringdata0[1718];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 24), // "on_ajouterclient_clicked"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 25), // "on_modifierclient_clicked"
QT_MOC_LITERAL(4, 63, 25), // "on_afficherclient_clicked"
QT_MOC_LITERAL(5, 89, 26), // "on_supprimerclient_clicked"
QT_MOC_LITERAL(6, 116, 23), // "on_export_excel_clicked"
QT_MOC_LITERAL(7, 140, 28), // "on_statistiqueclient_clicked"
QT_MOC_LITERAL(8, 169, 23), // "on_tri_idclient_clicked"
QT_MOC_LITERAL(9, 193, 23), // "on_trinomclient_clicked"
QT_MOC_LITERAL(10, 217, 26), // "on_triprenomclient_clicked"
QT_MOC_LITERAL(11, 244, 25), // "on_rechercher_textChanged"
QT_MOC_LITERAL(12, 270, 20), // "controlSaisie_client"
QT_MOC_LITERAL(13, 291, 12), // "update_label"
QT_MOC_LITERAL(14, 304, 18), // "on_sendBtn_clicked"
QT_MOC_LITERAL(15, 323, 26), // "on_ajouteremployer_clicked"
QT_MOC_LITERAL(16, 350, 28), // "on_afficher_employer_clicked"
QT_MOC_LITERAL(17, 379, 29), // "on_supprimer_employer_clicked"
QT_MOC_LITERAL(18, 409, 23), // "on_modifier_emp_clicked"
QT_MOC_LITERAL(19, 433, 17), // "on_qrcode_clicked"
QT_MOC_LITERAL(20, 451, 31), // "on_statistique_employer_clicked"
QT_MOC_LITERAL(21, 483, 17), // "on_pdfemp_clicked"
QT_MOC_LITERAL(22, 501, 27), // "on_stat_salaire_emp_clicked"
QT_MOC_LITERAL(23, 529, 29), // "on_rechercher_emp_textChanged"
QT_MOC_LITERAL(24, 559, 25), // "on_tri_salaireemp_clicked"
QT_MOC_LITERAL(25, 585, 22), // "on_tri_nom_emp_clicked"
QT_MOC_LITERAL(26, 608, 20), // "on_tab_emp_activated"
QT_MOC_LITERAL(27, 629, 5), // "index"
QT_MOC_LITERAL(28, 635, 18), // "on_Ajouter_clicked"
QT_MOC_LITERAL(29, 654, 19), // "on_Afficher_clicked"
QT_MOC_LITERAL(30, 674, 20), // "on_Supprimer_clicked"
QT_MOC_LITERAL(31, 695, 19), // "on_Modifier_clicked"
QT_MOC_LITERAL(32, 715, 21), // "on_tri_id_emp_clicked"
QT_MOC_LITERAL(33, 737, 16), // "update_label_emp"
QT_MOC_LITERAL(34, 754, 16), // "update_labelbien"
QT_MOC_LITERAL(35, 771, 37), // "on_pushButton_tri_nbr_employe..."
QT_MOC_LITERAL(36, 809, 30), // "on_pushButton_imprimer_clicked"
QT_MOC_LITERAL(37, 840, 36), // "on_pushButton_tri_nbr_client_..."
QT_MOC_LITERAL(38, 877, 29), // "on_pushButton_ajouter_clicked"
QT_MOC_LITERAL(39, 907, 30), // "on_pushButton_modifier_clicked"
QT_MOC_LITERAL(40, 938, 31), // "on_pushButton_supprimer_clicked"
QT_MOC_LITERAL(41, 970, 32), // "on_pushButton_tri_budget_clicked"
QT_MOC_LITERAL(42, 1003, 28), // "on_pushButton_tri_id_clicked"
QT_MOC_LITERAL(43, 1032, 33), // "on_pushButton_statistique_cli..."
QT_MOC_LITERAL(44, 1066, 33), // "on_lineEdit_recherche_textCha..."
QT_MOC_LITERAL(45, 1100, 16), // "on_login_clicked"
QT_MOC_LITERAL(46, 1117, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(47, 1139, 18), // "on_tab_emp_clicked"
QT_MOC_LITERAL(48, 1158, 4), // "arg1"
QT_MOC_LITERAL(49, 1163, 26), // "on_statistiquebien_clicked"
QT_MOC_LITERAL(50, 1190, 27), // "on_statistique_bien_clicked"
QT_MOC_LITERAL(51, 1218, 25), // "on_supprimer_bien_clicked"
QT_MOC_LITERAL(52, 1244, 21), // "on_actualiser_clicked"
QT_MOC_LITERAL(53, 1266, 24), // "on_modifier_bien_clicked"
QT_MOC_LITERAL(54, 1291, 23), // "on_ajouter_bien_clicked"
QT_MOC_LITERAL(55, 1315, 30), // "on_rechercher_bien_textChanged"
QT_MOC_LITERAL(56, 1346, 21), // "on_comboBox_activated"
QT_MOC_LITERAL(57, 1368, 17), // "controlSaisiebien"
QT_MOC_LITERAL(58, 1386, 10), // "myfunction"
QT_MOC_LITERAL(59, 1397, 18), // "controlSaisiemodif"
QT_MOC_LITERAL(60, 1416, 31), // "on_pushButton_ajouter_2_clicked"
QT_MOC_LITERAL(61, 1448, 32), // "on_pushButton_modifier_2_clicked"
QT_MOC_LITERAL(62, 1481, 31), // "on_pushButton_ajouter_3_clicked"
QT_MOC_LITERAL(63, 1513, 33), // "on_pushButton_supprimer_2_cli..."
QT_MOC_LITERAL(64, 1547, 16), // "controlSaisierec"
QT_MOC_LITERAL(65, 1564, 31), // "on_pushButton_merier1_3_clicked"
QT_MOC_LITERAL(66, 1596, 31), // "on_pushButton_merier1_2_clicked"
QT_MOC_LITERAL(67, 1628, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(68, 1652, 29), // "on_rechercher_rec_textChanged"
QT_MOC_LITERAL(69, 1682, 17), // "on_ouvrir_clicked"
QT_MOC_LITERAL(70, 1700, 17) // "on_Fermer_clicked"

    },
    "MainWindow\0on_ajouterclient_clicked\0"
    "\0on_modifierclient_clicked\0"
    "on_afficherclient_clicked\0"
    "on_supprimerclient_clicked\0"
    "on_export_excel_clicked\0"
    "on_statistiqueclient_clicked\0"
    "on_tri_idclient_clicked\0on_trinomclient_clicked\0"
    "on_triprenomclient_clicked\0"
    "on_rechercher_textChanged\0"
    "controlSaisie_client\0update_label\0"
    "on_sendBtn_clicked\0on_ajouteremployer_clicked\0"
    "on_afficher_employer_clicked\0"
    "on_supprimer_employer_clicked\0"
    "on_modifier_emp_clicked\0on_qrcode_clicked\0"
    "on_statistique_employer_clicked\0"
    "on_pdfemp_clicked\0on_stat_salaire_emp_clicked\0"
    "on_rechercher_emp_textChanged\0"
    "on_tri_salaireemp_clicked\0"
    "on_tri_nom_emp_clicked\0on_tab_emp_activated\0"
    "index\0on_Ajouter_clicked\0on_Afficher_clicked\0"
    "on_Supprimer_clicked\0on_Modifier_clicked\0"
    "on_tri_id_emp_clicked\0update_label_emp\0"
    "update_labelbien\0on_pushButton_tri_nbr_employe_clicked\0"
    "on_pushButton_imprimer_clicked\0"
    "on_pushButton_tri_nbr_client_clicked\0"
    "on_pushButton_ajouter_clicked\0"
    "on_pushButton_modifier_clicked\0"
    "on_pushButton_supprimer_clicked\0"
    "on_pushButton_tri_budget_clicked\0"
    "on_pushButton_tri_id_clicked\0"
    "on_pushButton_statistique_clicked\0"
    "on_lineEdit_recherche_textChanged\0"
    "on_login_clicked\0on_pushButton_clicked\0"
    "on_tab_emp_clicked\0arg1\0"
    "on_statistiquebien_clicked\0"
    "on_statistique_bien_clicked\0"
    "on_supprimer_bien_clicked\0"
    "on_actualiser_clicked\0on_modifier_bien_clicked\0"
    "on_ajouter_bien_clicked\0"
    "on_rechercher_bien_textChanged\0"
    "on_comboBox_activated\0controlSaisiebien\0"
    "myfunction\0controlSaisiemodif\0"
    "on_pushButton_ajouter_2_clicked\0"
    "on_pushButton_modifier_2_clicked\0"
    "on_pushButton_ajouter_3_clicked\0"
    "on_pushButton_supprimer_2_clicked\0"
    "controlSaisierec\0on_pushButton_merier1_3_clicked\0"
    "on_pushButton_merier1_2_clicked\0"
    "on_pushButton_7_clicked\0"
    "on_rechercher_rec_textChanged\0"
    "on_ouvrir_clicked\0on_Fermer_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      68,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  354,    2, 0x08 /* Private */,
       3,    0,  355,    2, 0x08 /* Private */,
       4,    0,  356,    2, 0x08 /* Private */,
       5,    0,  357,    2, 0x08 /* Private */,
       6,    0,  358,    2, 0x08 /* Private */,
       7,    0,  359,    2, 0x08 /* Private */,
       8,    0,  360,    2, 0x08 /* Private */,
       9,    0,  361,    2, 0x08 /* Private */,
      10,    0,  362,    2, 0x08 /* Private */,
      11,    0,  363,    2, 0x08 /* Private */,
      12,    0,  364,    2, 0x08 /* Private */,
      13,    0,  365,    2, 0x08 /* Private */,
      14,    0,  366,    2, 0x08 /* Private */,
      15,    0,  367,    2, 0x08 /* Private */,
      16,    0,  368,    2, 0x08 /* Private */,
      17,    0,  369,    2, 0x08 /* Private */,
      18,    0,  370,    2, 0x08 /* Private */,
      19,    0,  371,    2, 0x08 /* Private */,
      20,    0,  372,    2, 0x08 /* Private */,
      21,    0,  373,    2, 0x08 /* Private */,
      22,    0,  374,    2, 0x08 /* Private */,
      23,    0,  375,    2, 0x08 /* Private */,
      24,    0,  376,    2, 0x08 /* Private */,
      25,    0,  377,    2, 0x08 /* Private */,
      26,    1,  378,    2, 0x08 /* Private */,
      28,    0,  381,    2, 0x08 /* Private */,
      29,    0,  382,    2, 0x08 /* Private */,
      30,    0,  383,    2, 0x08 /* Private */,
      31,    0,  384,    2, 0x08 /* Private */,
      32,    0,  385,    2, 0x08 /* Private */,
      33,    0,  386,    2, 0x08 /* Private */,
      34,    0,  387,    2, 0x08 /* Private */,
      35,    0,  388,    2, 0x08 /* Private */,
      36,    0,  389,    2, 0x08 /* Private */,
      37,    0,  390,    2, 0x08 /* Private */,
      38,    0,  391,    2, 0x08 /* Private */,
      39,    0,  392,    2, 0x08 /* Private */,
      40,    0,  393,    2, 0x08 /* Private */,
      41,    0,  394,    2, 0x08 /* Private */,
      42,    0,  395,    2, 0x08 /* Private */,
      43,    0,  396,    2, 0x08 /* Private */,
      44,    0,  397,    2, 0x08 /* Private */,
      45,    0,  398,    2, 0x08 /* Private */,
      46,    0,  399,    2, 0x08 /* Private */,
      47,    1,  400,    2, 0x08 /* Private */,
      23,    1,  403,    2, 0x08 /* Private */,
      49,    0,  406,    2, 0x08 /* Private */,
      50,    0,  407,    2, 0x08 /* Private */,
      51,    0,  408,    2, 0x08 /* Private */,
      52,    0,  409,    2, 0x08 /* Private */,
      53,    0,  410,    2, 0x08 /* Private */,
      54,    0,  411,    2, 0x08 /* Private */,
      55,    1,  412,    2, 0x08 /* Private */,
      56,    1,  415,    2, 0x08 /* Private */,
      57,    0,  418,    2, 0x08 /* Private */,
      58,    0,  419,    2, 0x08 /* Private */,
      59,    0,  420,    2, 0x08 /* Private */,
      60,    0,  421,    2, 0x08 /* Private */,
      61,    0,  422,    2, 0x08 /* Private */,
      62,    0,  423,    2, 0x08 /* Private */,
      63,    0,  424,    2, 0x08 /* Private */,
      64,    0,  425,    2, 0x08 /* Private */,
      65,    0,  426,    2, 0x08 /* Private */,
      66,    0,  427,    2, 0x08 /* Private */,
      67,    0,  428,    2, 0x08 /* Private */,
      68,    1,  429,    2, 0x08 /* Private */,
      69,    0,  432,    2, 0x08 /* Private */,
      70,    0,  433,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QModelIndex,   27,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QModelIndex,   27,
    QMetaType::Void, QMetaType::QString,   48,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   48,
    QMetaType::Void, QMetaType::QString,   48,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   48,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_ajouterclient_clicked(); break;
        case 1: _t->on_modifierclient_clicked(); break;
        case 2: _t->on_afficherclient_clicked(); break;
        case 3: _t->on_supprimerclient_clicked(); break;
        case 4: _t->on_export_excel_clicked(); break;
        case 5: _t->on_statistiqueclient_clicked(); break;
        case 6: _t->on_tri_idclient_clicked(); break;
        case 7: _t->on_trinomclient_clicked(); break;
        case 8: _t->on_triprenomclient_clicked(); break;
        case 9: _t->on_rechercher_textChanged(); break;
        case 10: { bool _r = _t->controlSaisie_client();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        //case 11: _t->update_label(); break;
        case 12: _t->on_sendBtn_clicked(); break;
        case 13: _t->on_ajouteremployer_clicked(); break;
        case 14: _t->on_afficher_employer_clicked(); break;
        case 15: _t->on_supprimer_employer_clicked(); break;
        case 16: _t->on_modifier_emp_clicked(); break;
        case 17: _t->on_qrcode_clicked(); break;
        case 18: _t->on_statistique_employer_clicked(); break;
        case 19: _t->on_pdfemp_clicked(); break;
        case 20: _t->on_stat_salaire_emp_clicked(); break;
        case 21: _t->on_rechercher_emp_textChanged(); break;
        case 22: _t->on_tri_salaireemp_clicked(); break;
        case 23: _t->on_tri_nom_emp_clicked(); break;
       // case 24: _t->on_tab_emp_activated((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 25: _t->on_Ajouter_clicked(); break;
        case 26: _t->on_Afficher_clicked(); break;
        case 27: _t->on_Supprimer_clicked(); break;
        case 28: _t->on_Modifier_clicked(); break;
        case 29: _t->on_tri_id_emp_clicked(); break;
        case 30: _t->update_label_emp(); break;
        case 31: _t->update_labelbien(); break;
        case 32: _t->on_pushButton_tri_nbr_employe_clicked(); break;
        case 33: _t->on_pushButton_imprimer_clicked(); break;
        case 34: _t->on_pushButton_tri_nbr_client_clicked(); break;
        case 35: _t->on_pushButton_ajouter_clicked(); break;
        case 36: _t->on_pushButton_modifier_clicked(); break;
        case 37: _t->on_pushButton_supprimer_clicked(); break;
        case 38: _t->on_pushButton_tri_budget_clicked(); break;
        case 39: _t->on_pushButton_tri_id_clicked(); break;
        case 40: _t->on_pushButton_statistique_clicked(); break;
        case 41: _t->on_lineEdit_recherche_textChanged(); break;
        case 42: _t->on_login_clicked(); break;
       // case 43: _t->on_pushButton_clicked(); break;
        case 44: _t->on_tab_emp_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 45: _t->on_rechercher_emp_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
       // case 46: _t->on_statistiquebien_clicked(); break;
        case 47: _t->on_statistique_bien_clicked(); break;
        case 48: _t->on_supprimer_bien_clicked(); break;
        case 49: _t->on_actualiser_clicked(); break;
        case 50: _t->on_modifier_bien_clicked(); break;
        case 51: _t->on_ajouter_bien_clicked(); break;
        case 52: _t->on_rechercher_bien_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 53: _t->on_comboBox_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 54: { bool _r = _t->controlSaisiebien();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 55: _t->myfunction(); break;
        case 56: { bool _r = _t->controlSaisiemodif();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 57: _t->on_pushButton_ajouter_2_clicked(); break;
        case 58: _t->on_pushButton_modifier_2_clicked(); break;
        case 59: _t->on_pushButton_ajouter_3_clicked(); break;
        case 60: _t->on_pushButton_supprimer_2_clicked(); break;
        case 61: { bool _r = _t->controlSaisierec();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 62: _t->on_pushButton_merier1_3_clicked(); break;
        case 63: _t->on_pushButton_merier1_2_clicked(); break;
        case 64: _t->on_pushButton_7_clicked(); break;
        case 65: _t->on_rechercher_rec_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 66: _t->on_ouvrir_clicked(); break;
        case 67: _t->on_Fermer_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 68)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 68;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 68)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 68;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
