/********************************************************************************
** Form generated from reading UI file 'statistiques.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTIQUES_H
#define UI_STATISTIQUES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_statistiques
{
public:
    QWidget *widget;
    QWidget *widget_2;
    QLabel *label_2;
    QLabel *label_8;
    QLabel *label_3;
    QLabel *label;
    QLabel *label_4;
    QLabel *label_7;
    QLabel *label_5;
    QLabel *label_6;
    QWidget *widget_3;
    QWidget *widget_4;
    QPushButton *pushButton;

    void setupUi(QWidget *statistiques)
    {
        if (statistiques->objectName().isEmpty())
            statistiques->setObjectName(QStringLiteral("statistiques"));
        statistiques->resize(812, 604);
        statistiques->setStyleSheet(QStringLiteral(""));
        widget = new QWidget(statistiques);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(610, 80, 20, 20));
        widget->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 255);"));
        widget_2 = new QWidget(statistiques);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(610, 110, 20, 20));
        widget_2->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 255);"));
        label_2 = new QLabel(statistiques);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(640, 80, 111, 16));
        label_2->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_8 = new QLabel(statistiques);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(140, 490, 461, 41));
        label_8->setStyleSheet(QLatin1String("font: 18pt \"MS Shell Dlg 2\";\n"
"color: rgb(0, 170, 255);"));
        label_3 = new QLabel(statistiques);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(640, 110, 101, 16));
        label_3->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label = new QLabel(statistiques);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(606, 49, 131, 31));
        label->setStyleSheet(QStringLiteral("font: 75 italic 14pt \"Arial\";"));
        label_4 = new QLabel(statistiques);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(640, 150, 131, 16));
        label_4->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_7 = new QLabel(statistiques);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(720, 170, 31, 31));
        label_5 = new QLabel(statistiques);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(710, 100, 71, 31));
        label_6 = new QLabel(statistiques);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(640, 180, 101, 16));
        label_6->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        widget_3 = new QWidget(statistiques);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(610, 150, 20, 20));
        widget_3->setStyleSheet(QStringLiteral("background-color: rgb(255, 0, 0)"));
        widget_4 = new QWidget(statistiques);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        widget_4->setGeometry(QRect(610, 180, 20, 20));
        widget_4->setStyleSheet(QStringLiteral("background-color: rgb(255, 0, 0)"));
        pushButton = new QPushButton(statistiques);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(40, 540, 75, 23));

        retranslateUi(statistiques);

        QMetaObject::connectSlotsByName(statistiques);
    } // setupUi

    void retranslateUi(QWidget *statistiques)
    {
        statistiques->setWindowTitle(QApplication::translate("statistiques", "Form", Q_NULLPTR));
        label_2->setText(QApplication::translate("statistiques", "TextLabel", Q_NULLPTR));
        label_8->setText(QApplication::translate("statistiques", "Statistique par  salaire_Employee", Q_NULLPTR));
        label_3->setText(QApplication::translate("statistiques", "TextLabel", Q_NULLPTR));
        label->setText(QApplication::translate("statistiques", "Pourcentage", Q_NULLPTR));
        label_4->setText(QApplication::translate("statistiques", "TextLabel", Q_NULLPTR));
        label_7->setText(QApplication::translate("statistiques", "%", Q_NULLPTR));
        label_5->setText(QApplication::translate("statistiques", "%", Q_NULLPTR));
        label_6->setText(QApplication::translate("statistiques", "TextLabel", Q_NULLPTR));
        pushButton->setText(QApplication::translate("statistiques", "PushButton", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class statistiques: public Ui_statistiques {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTIQUES_H
