/********************************************************************************
** Form generated from reading UI file 'statistique-cl.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTIQUE_2D_CL_H
#define UI_STATISTIQUE_2D_CL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_statistique
{
public:
    QLabel *label_8;
    QWidget *widget;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label;
    QWidget *widget_3;
    QWidget *widget_5;
    QLabel *label_5;
    QLabel *label_4;
    QLabel *label_6;
    QWidget *widget_4;
    QWidget *widget_2;

    void setupUi(QWidget *statistique)
    {
        if (statistique->objectName().isEmpty())
            statistique->setObjectName(QStringLiteral("statistique"));
        statistique->resize(953, 634);
        label_8 = new QLabel(statistique);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(270, 479, 481, 41));
        label_8->setStyleSheet(QLatin1String("font: 18pt \"MS Shell Dlg 2\";\n"
"color: rgb(0, 170, 255);"));
        widget = new QWidget(statistique);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(720, 80, 20, 20));
        widget->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 255);"));
        label_3 = new QLabel(statistique);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(750, 110, 111, 16));
        label_3->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_2 = new QLabel(statistique);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(750, 80, 111, 16));
        label_2->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label = new QLabel(statistique);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(716, 49, 131, 31));
        label->setStyleSheet(QStringLiteral("font: 75 italic 14pt \"Arial\";"));
        widget_3 = new QWidget(statistique);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(720, 210, 21, 20));
        widget_3->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"background-color: rgb(255, 0, 0);"));
        widget_5 = new QWidget(statistique);
        widget_5->setObjectName(QStringLiteral("widget_5"));
        widget_5->setGeometry(QRect(720, 110, 20, 20));
        widget_5->setStyleSheet(QStringLiteral("background-color: rgb(0, 255, 0);"));
        label_5 = new QLabel(statistique);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(750, 180, 111, 16));
        label_5->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_4 = new QLabel(statistique);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(750, 150, 131, 16));
        label_4->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_6 = new QLabel(statistique);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(750, 210, 111, 16));
        label_6->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        widget_4 = new QWidget(statistique);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        widget_4->setGeometry(QRect(720, 180, 20, 20));
        widget_4->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"background-color: rgb(255, 255, 0);"));
        widget_2 = new QWidget(statistique);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(720, 150, 20, 20));
        widget_2->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));

        retranslateUi(statistique);

        QMetaObject::connectSlotsByName(statistique);
    } // setupUi

    void retranslateUi(QWidget *statistique)
    {
        statistique->setWindowTitle(QApplication::translate("statistique", "Form", Q_NULLPTR));
        label_8->setText(QApplication::translate("statistique", " statistique d'Adresse ", Q_NULLPTR));
        label_3->setText(QApplication::translate("statistique", "Tunis", Q_NULLPTR));
        label_2->setText(QApplication::translate("statistique", "Bizerte", Q_NULLPTR));
        label->setText(QApplication::translate("statistique", "Pourcentage", Q_NULLPTR));
        label_5->setText(QApplication::translate("statistique", "Sfax", Q_NULLPTR));
        label_4->setText(QApplication::translate("statistique", "Nabeul", Q_NULLPTR));
        label_6->setText(QApplication::translate("statistique", "Sousse", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class statistique: public Ui_statistique {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTIQUE_2D_CL_H
