/********************************************************************************
** Form generated from reading UI file 'statistique_rec.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTIQUE_REC_H
#define UI_STATISTIQUE_REC_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_statistique_rec
{
public:
    QLabel *label_3;
    QWidget *widget_5;
    QWidget *widget;
    QLabel *label;
    QLabel *label_8;
    QLabel *label_2;

    void setupUi(QWidget *statistique_rec)
    {
        if (statistique_rec->objectName().isEmpty())
            statistique_rec->setObjectName(QStringLiteral("statistique_rec"));
        statistique_rec->resize(726, 584);
        label_3 = new QLabel(statistique_rec);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(510, 211, 111, 16));
        label_3->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        widget_5 = new QWidget(statistique_rec);
        widget_5->setObjectName(QStringLiteral("widget_5"));
        widget_5->setGeometry(QRect(480, 160, 20, 20));
        widget_5->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        widget = new QWidget(statistique_rec);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(480, 210, 20, 20));
        widget->setStyleSheet(QLatin1String("background-color: rgb(255, 0, 0);\n"
""));
        label = new QLabel(statistique_rec);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(476, 110, 131, 31));
        label->setStyleSheet(QStringLiteral("font: 75 italic 14pt \"Arial\";"));
        label_8 = new QLabel(statistique_rec);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(280, 410, 131, 41));
        label_8->setStyleSheet(QLatin1String("font: 18pt \"MS Shell Dlg 2\";\n"
"color: rgb(0, 170, 255);"));
        label_2 = new QLabel(statistique_rec);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(510, 161, 111, 16));
        label_2->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));

        retranslateUi(statistique_rec);

        QMetaObject::connectSlotsByName(statistique_rec);
    } // setupUi

    void retranslateUi(QWidget *statistique_rec)
    {
        statistique_rec->setWindowTitle(QApplication::translate("statistique_rec", "Form", Q_NULLPTR));
        label_3->setText(QApplication::translate("statistique_rec", "employe", Q_NULLPTR));
        label->setText(QApplication::translate("statistique_rec", "Pourcentage", Q_NULLPTR));
        label_8->setText(QApplication::translate("statistique_rec", "Statistique ", Q_NULLPTR));
        label_2->setText(QApplication::translate("statistique_rec", "client", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class statistique_rec: public Ui_statistique_rec {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTIQUE_REC_H
