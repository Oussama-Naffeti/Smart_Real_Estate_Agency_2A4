#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "authentification.h"
#include <QMainWindow>
#include "exportexcelobject.h"
#include "smtp.h"
#include "arduino.h"
#include "client.h"
#include "employe.h"
#include "agence.h"
#include "bien.h"
#include "statistique.h"
#include "rec.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    Smtp* smtp;
    QString msg;
    QString mail;
public:
    MainWindow(QWidget *parent = nullptr);
    void refresh();
    void clear();
    bool controlSaisie();
    bool controlSaisie1();
    ~MainWindow();

private slots:
    //client
    void on_ajouterclient_clicked();

    void on_modifierclient_clicked();

    void on_afficherclient_clicked();

    void on_supprimerclient_clicked();

    void on_export_excel_clicked();

    void on_statistiqueclient_clicked();

    void on_tri_idclient_clicked();

    void on_trinomclient_clicked();

    void on_triprenomclient_clicked();

    void on_rechercher_textChanged();

   bool controlSaisie_client();

   void update_label();

   void on_sendBtn_clicked();

   //employer

   void on_ajouteremployer_clicked();

   void on_afficher_employer_clicked();

   void on_supprimer_employer_clicked();

   void on_modifier_emp_clicked();

   void on_qrcode_clicked();

   void on_statistique_employer_clicked();

   void on_pdfemp_clicked();

   void on_stat_salaire_emp_clicked();

   void on_rechercher_emp_textChanged();

   void on_tri_salaireemp_clicked();

   void on_tri_nom_emp_clicked();

   void on_tab_emp_activated(const QModelIndex &index);

   void on_Ajouter_clicked();

   void on_Afficher_clicked();

   void on_Supprimer_clicked();

   void on_Modifier_clicked();

   void on_tri_id_emp_clicked();

   void update_label_emp();

   void on_pushButton_tri_nbr_employe_clicked();

   void on_pushButton_imprimer_clicked();

   void on_pushButton_tri_nbr_client_clicked();

   void on_pushButton_ajouter_clicked();

   void on_pushButton_modifier_clicked();

   void on_pushButton_supprimer_clicked();

   void on_pushButton_tri_budget_clicked();

   void on_pushButton_tri_id_clicked();

   void on_pushButton_statistique_clicked();

   void on_lineEdit_recherche_textChanged();

   void on_login_clicked();

   void on_pushButton_clicked();

   void on_tab_emp_clicked(const QModelIndex &index);

   void on_rechercher_emp_textChanged(const QString &arg1);

   void on_statistiquebien_clicked();

   void on_statistique_bien_clicked();
   
   void on_supprimer_bien_clicked();
   
   void on_actualiser_clicked();
   
   void on_modifier_bien_clicked();
   
   void on_ajouter_bien_clicked();
   
   void on_rechercher_bien_textChanged(const QString &arg1);
   
   void on_comboBox_activated(const QString &arg1);

   bool controlSaisiebien();


    void myfunction();

    bool controlSaisiemodif() ;
    void on_pushButton_ajouter_2_clicked();

    void on_pushButton_modifier_2_clicked();

    void on_pushButton_ajouter_3_clicked();

    void on_pushButton_supprimer_2_clicked();

    bool controlSaisierec();

    void on_pushButton_merier1_3_clicked();

    void on_pushButton_merier1_2_clicked();

    void on_pushButton_7_clicked();

    void on_rechercher_rec_textChanged(const QString &arg1);

private:
    Ui::MainWindow *ui;

    client cl;
    //arduino
    QByteArray data; // variable contenant les données reçues

    Arduino A; // objet temporaire

    Employe e;
    authentification auth;
    //agence
     Agence Etmp;
      bien b;
      QTimer *timer;
    statistique sb;

    //reclamation
    recl r,r1;
};
#endif // MAINWINDOW_H
