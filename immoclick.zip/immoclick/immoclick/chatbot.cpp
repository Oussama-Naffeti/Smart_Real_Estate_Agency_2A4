/*#include "chatbot.h"
#include "ui_chatbot.h"
#include "ui_mainwindow.h"
#include<iostream>
#include "mainwindow.h"

chatbot::chatbot(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::chatbot)
{
    ui->setupUi(this);
}

chatbot::~chatbot()
{
    delete ui;
}

void chatbot::on_pushButton_clicked()
{
     ui->label_3->setText("");//1 question
     if(lineEdit=='1')
     {
         ui->lineEdit->clear();
         ui->label_3->setText("");//2 question
         if(lineEdit=='1')
         {
             ui->lineEdit->clear();
             ui->label_3->setText("");


         }
         else if (lineEdit=='2') {
             ui->lineEdit->clear();
             ui->label_3->setText("");

         }
         else if (lineEdit=='3') {
             ui->lineEdit->clear();
             ui->label_3->setText("");

         }




     }
     else if (lineEdit=='2') {
         ui->lineEdit->clear();
         ui->label_3->setText("");//2 question
         if(lineEdit=='1')
         {
             ui->lineEdit->clear();
             ui->label_3->setText("");


         }
         else if (lineEdit=='2') {
             ui->lineEdit->clear();
             ui->label_3->setText("");

         }
         else if (lineEdit=='3') {
             ui->lineEdit->clear();
             ui->label_3->setText("");

         }


     }

     else if (lineEdit=='3'){

         ui->lineEdit->clear();
         ui->label_3->setText("");//2 question
         if(lineEdit=='1')
         {
             ui->lineEdit->clear();
             ui->label_3->setText("");


         }
         else if (lineEdit=='2') {
             ui->lineEdit->clear();
             ui->label_3->setText("");

         }
         else if (lineEdit=='3') {
             ui->lineEdit->clear();
             ui->label_3->setText("");

         }





     }



     ui->lineEdit->clear();

}

*/
