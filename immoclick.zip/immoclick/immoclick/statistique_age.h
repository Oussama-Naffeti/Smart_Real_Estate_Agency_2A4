#ifndef STATISTIQUE_AGE_H
#define STATISTIQUE_AGE_H

#include <QDialog>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QPainter>
#include <QSqlQuery>

using namespace std;

namespace Ui {
class statistique_age;
}

class statistique_age : public QDialog
{
    Q_OBJECT

public:
    explicit statistique_age(QWidget *parent = nullptr);
    int statistique_age_partie2() ;
        int statistique_age_partie3() ;
         int statistique_age_partie4() ;
         int statistique_age_partie5() ;
         int statistique_age_partie6() ;
        void paintEvent(QPaintEvent *) ;

    ~statistique_age();

private:
    Ui::statistique_age *ui;
private slots :
};

#endif // STATISTIQUE_AGE_H
