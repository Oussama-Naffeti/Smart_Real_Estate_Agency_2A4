#ifndef STATISTIQUE_REC_H
#define STATISTIQUE_REC_H


#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QPainter>
#include <QSqlQuery>
#include <QDialog>
using namespace std;

namespace Ui {
class statistique_rec;
}

class statistique_rec : public QDialog
{
    Q_OBJECT

public:
    explicit statistique_rec(QWidget *parent = nullptr);
    int Statistique_partie2() ;
        int Statistique_partie3() ;

        void paintEvent(QPaintEvent *) ;

    ~statistique_rec();

private:
    Ui::statistique_rec *ui;
private slots :
};




#endif // STATISTIQUE_REC_H

