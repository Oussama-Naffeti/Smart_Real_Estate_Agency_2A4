#include "rec.h"
#include "arduino.h"
#include <QSqlQuery>
#include<QtDebug>
#include <QObject>
#include <QMessageBox>
#include <QIntValidator>
#include <QSqlQueryModel>

recl::recl()
{
    id=0;
    type="";
    date="";
    titre="";
    description="";
  }


recl::recl(int id, QString type, QString date, QString titre, QString description)
{       this->date=date;
        this->description=description;


        this->titre=titre;
        this->type=type;
this->id=id;
}


bool recl::ajouter()
    {

        QSqlQuery query;
        QString id_string=QString::number(id);
              query.prepare("INSERT INTO RECLAMATION (date_r,description,titre,type,id) "
                            "VALUES ( :date, :description, :titre,  :type, :id )");

              query.bindValue(":date", date);
              query.bindValue(":description", description);
              query.bindValue(":titre", titre);
              query.bindValue(":type", type);
              query.bindValue(":id",id_string);



              return query.exec();
    }

bool recl::update(int id)
    {
    QSqlQuery query;
       QString id_string = QString::number(id); //res
       query.prepare("UPDATE RECLAMATION SET type= :type, date= :date, titre= :titre ,description=:description  WHERE id= :id");
       query.bindValue(":date",date);
       query.bindValue(":description",description);
       query.bindValue(":titre",titre);
       query.bindValue(":type",type);
       query.bindValue(":id",id_string); //changer id  a res




       return query.exec();




}




bool recl::supprimer(int)
    {
    QSqlQuery query;
     QString id_string=QString::number(id);
          query.prepare("DELETE FROM RECLAMATION WHERE id=:id");
          query.bindValue(":id", id);


          return query.exec();
    }


QSqlQueryModel* recl::afficher()
{
  QSqlQueryModel* model =new QSqlQueryModel();

  model->setQuery("SELECT * FROM RECLAMATION");

  model->setHeaderData(0, Qt::Horizontal, QObject::tr("date"));
  model->setHeaderData(1, Qt::Horizontal, QObject::tr("description"));
  model->setHeaderData(2, Qt::Horizontal, QObject::tr("titre"));
  model->setHeaderData(3, Qt::Horizontal, QObject::tr("type"));
  model->setHeaderData(4, Qt::Horizontal, QObject::tr("id"));


return model;
}




QSqlQueryModel * recl::recherche(QString recherche)
{
    QSqlQueryModel* model = new QSqlQueryModel();

    model->setQuery("SELECT * FROM RECLAMATION WHERE id LIKE '"+recherche+"%' OR type LIKE '"+recherche+"%' ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("DATE"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("DESCRIPTION"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TITRE"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("TYPE"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("ID"));

    return model;
}
//fonction tri*********
QSqlQueryModel * recl::triParId()
{
    QSqlQueryModel * model=new QSqlQueryModel();
    model->setQuery("SELECT * from RECLAMATION ORDER BY ID DESC");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("DATE"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("DESCRIPTION"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TITRE"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("TYPE"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("ID"));




    return model;
}
bool recl::recExist(int id){
    QSqlQueryModel * model= new QSqlQueryModel();
    QString id_string= QString::number(id);
    model->setQuery("select * from RECLAMATION WHERE id="+id_string);
    return  model->rowCount();
}


QSqlQueryModel * recl::triParType()
{
    QSqlQueryModel * model=new QSqlQueryModel();
    model->setQuery("SELECT * from RECLAMATION ORDER BY TYPE ASC");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("DATE"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("DESCRIPTION"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TITRE"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("TYPE"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("ID"));




    return model;
}


QSqlQueryModel * recl::triParType1()
{
    QSqlQueryModel * model=new QSqlQueryModel();
    model->setQuery("SELECT * from RECLAMATION ORDER BY TYPE DESC");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("DATE"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("DESCRIPTION"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TITRE"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("TYPE"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("ID"));




    return model;
}






