#include "statistique_rec.h"
#include "ui_statistique_rec.h"
#include "ui_mainwindow.h"
#include<iostream>
#include "mainwindow.h"


statistique_rec::statistique_rec(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::statistique_rec)
{
    ui->setupUi(this);
}

statistique_rec::~statistique_rec()
{
    delete ui;
}
int statistique_rec::Statistique_partie2()
{
    QSqlQuery query;
    int count=0 ;
    QSqlQuery requete("select * from RECLAMATION where type = 'client'") ;
    while(requete.next())
    {
            count++ ;
    }

return count ;
}

int statistique_rec::Statistique_partie3()
{
    QSqlQuery query;
    int count=0 ;
    QSqlQuery requete("select * from RECLAMATION where type = 'employe'") ;
    while(requete.next())
    {
            count++ ;
    }

return count ;
}

void statistique_rec::paintEvent(QPaintEvent *)
{

    int a=Statistique_partie2();
    cout<<a<<endl ;
    int b=Statistique_partie3();
    cout<<b<<endl ;



        float s2= a*100 ;
        float s3=b*100;

        float nb = b+a ;
        float q2 ;
        q2 = s2/nb ;
        float q3;
        q3=s3/nb;

        float y  ;
        y = (q2*360)/100 ;
        float m;
        m= (q3*360)/100;

    QPainter painter(this);
    QRectF size=QRectF(150,40,this->width()-600,this->width()-600);

    painter.setBrush(Qt::black);
    painter.drawPie(size,0,16*y);

    painter.setBrush(Qt::red);
    painter.drawPie(size,16*y,16*m);
    painter.setBrush(Qt::black);



}

