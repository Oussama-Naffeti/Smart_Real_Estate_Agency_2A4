#include "bien.h"
#include <QSqlQuery>
#include <QtDebug>
#include <QObject>
#include <QMessageBox>
#include "mainwindow.h"

bien::bien()
{
    id=0;
    prix=0;
    categorie="";
    adresse="";
    statut="";

}
bien::bien(int id, QString categorie, int prix, QString adresse, QString statut)
{
    this->id=id;
    this->categorie=categorie;
    this->prix=prix;
    this->adresse=adresse;
    this->statut=statut;

}

int bien::get_id()
{
    return id;
}

int bien::get_Prix_c()
{
    return prix;
}

QString bien::get_Statut()
{
    return statut;
}
QString bien::get_Address()
{
    return adresse;
}
QString bien::get_Categorie_c()
{
    return categorie;
}

void bien::set_id(int id)
{
    this->id=id;

}

void bien::set_prix(int prix)
{
    this->prix=prix;
}

void bien::set_cat(QString categorie)
{
    this->categorie=categorie;
}

void bien::set_stat(QString status)
{
    this->statut=status;
}

void bien::set_adresse(QString adresse)
{
    this->adresse=adresse;
}


bool bien::ajouter()
{


    QSqlQuery query;
           query.prepare("INSERT INTO BIEN (ID, CATEGORIE, PRIX, ADRESSE, STATUT) "
                         "VALUES (:ID, :CATEGORIE, :PRIX, :ADRESSE,:STATUT)");
           query.bindValue(":ID",id);
           query.bindValue(":CATEGORIE",categorie);
           query.bindValue(":ADRESSE",adresse);
           query.bindValue(":STATUT",statut);
           query.bindValue(":PRIX",prix);

      query.exec();

        return  query.exec();

}
QSqlQueryModel* bien::afficher()
{

    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("SELECT * FROM BIEN ");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("CATEGORIE"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("PRIX"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("ADRESSE"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("STATUT"));


        return model;

}
bool bien::supprimer(int id)
{
    QSqlQuery query;
   query.prepare("DELETE from BIEN where ID=:ID") ;

                        query.bindValue(":ID",id );
                        query.exec();
}
bool bien::bienExist(int id){
    QSqlQueryModel * model= new QSqlQueryModel();
    QString res= QString::number(id);
    model->setQuery("select * from BIEN WHERE id="+res);
    return  model->rowCount();
}
QSqlQueryModel* bien::chercherbien(QString r)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("SELECT * FROM BIEN WHERE ID like ('%"+r+"%') or CATEGORIE like ('%"+r+"%') or ADRESSE like ('%"+r+"%') or  PRIX like ('%"+r+"%') or STATUT like ('%"+r+"%')");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID "));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("CATEGORIE"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("PRIX "));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("ADRESSE"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("STATUT"));


        return model;
}
QSqlQueryModel * bien::tri_bien(int tri)
{
     QSqlQueryModel * model= new QSqlQueryModel();
     switch (tri) {
   case 0:
        model->setQuery("SELECT * FROM BIEN");
          break;
   case 1:
         model->setQuery("SELECT * FROM BIEN ORDER BY ID ");
     break;
   case 2:
         model->setQuery("SELECT * FROM BIEN ORDER BY CATEGORIE ");
          break ;
   case 3:
        model->setQuery("SELECT * FROM BIEN ORDER BY ADRESSE ");
         break;

   case 4:
        model->setQuery("SELECT * FROM BIEN ORDER BY STATUT ");
         break;
     case 5:
          model->setQuery("SELECT * FROM BIEN ORDER BY PRIX ");
           break;

     }

     model->setHeaderData(0,Qt::Horizontal,QObject::tr("ID "));
     model->setHeaderData(1,Qt::Horizontal,QObject::tr("CATEGORIE"));
     model->setHeaderData(2,Qt::Horizontal,QObject::tr("PRIX "));
     model->setHeaderData(3,Qt::Horizontal,QObject::tr("ADRESSE"));
     model->setHeaderData(4,Qt::Horizontal,QObject::tr("STATUT"));

         return model;

}
