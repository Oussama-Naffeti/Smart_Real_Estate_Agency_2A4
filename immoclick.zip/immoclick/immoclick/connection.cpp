#include "connection.h"

Connection::Connection()
{

}

bool Connection::createconnection()
{
db = QSqlDatabase::addDatabase("QODBC");
bool test=false;
db.setDatabaseName("projet-2A");
db.setUserName("hend");//inserer nom de l'utilisateur
db.setPassword("esprit2A");//inserer mot de passe de cet utilisateur

if (db.open())
test=true;
return  test;
}

void Connection::closeConnection(){db.close();}
