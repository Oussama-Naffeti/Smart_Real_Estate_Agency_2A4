<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en" sourcelanguage="fr">
<context>
    <name>Form</name>
    <message>
        <location filename="chatbot.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatbot.ui" line="26"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;chatbot&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatbot.ui" line="39"/>
        <source>valider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatbot.ui" line="62"/>
        <source>reponse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatbot.ui" line="88"/>
        <source>quittez</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Gestion des Clients</source>
        <translation type="vanished">Customer Management</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="79"/>
        <source>Employés</source>
        <translation>Employees</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1544"/>
        <source>Clients</source>
        <translation>Customers</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2502"/>
        <source>Agences</source>
        <translation>Agencies</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="272"/>
        <location filename="mainwindow.ui" line="1104"/>
        <location filename="mainwindow.ui" line="2576"/>
        <location filename="mainwindow.ui" line="3131"/>
        <source>Ajouter</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2592"/>
        <source>Employé</source>
        <translation>Employee</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2604"/>
        <source>ID de l&apos;agence :</source>
        <translation>Agency ID :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="557"/>
        <location filename="mainwindow.ui" line="772"/>
        <location filename="mainwindow.ui" line="1759"/>
        <location filename="mainwindow.ui" line="2617"/>
        <location filename="mainwindow.ui" line="3231"/>
        <location filename="mainwindow.ui" line="3438"/>
        <source>Adresse :</source>
        <translation>Adress :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2630"/>
        <source>Budget :</source>
        <translation>Budget :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2672"/>
        <source>Nombre d&apos;employés :</source>
        <translation>Number of employees :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="596"/>
        <location filename="mainwindow.ui" line="870"/>
        <location filename="mainwindow.ui" line="1844"/>
        <location filename="mainwindow.ui" line="2703"/>
        <source>Tunis</source>
        <translation>Tunis</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2708"/>
        <source>Manouba</source>
        <translation>Manouba</translation>
    </message>
    <message>
        <source>Ariana</source>
        <translation type="vanished">Ariana</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2713"/>
        <source>Ben Arouss</source>
        <translation>Ben Arouss</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="611"/>
        <location filename="mainwindow.ui" line="885"/>
        <location filename="mainwindow.ui" line="1859"/>
        <location filename="mainwindow.ui" line="2718"/>
        <source>Sousse</source>
        <translation>Sousse</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="591"/>
        <location filename="mainwindow.ui" line="865"/>
        <location filename="mainwindow.ui" line="1839"/>
        <location filename="mainwindow.ui" line="2723"/>
        <source>Bizerte</source>
        <translation>Bizerte</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="601"/>
        <location filename="mainwindow.ui" line="875"/>
        <location filename="mainwindow.ui" line="1849"/>
        <location filename="mainwindow.ui" line="2728"/>
        <source>Nabeul</source>
        <translation>Nabeul</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="311"/>
        <location filename="mainwindow.ui" line="1065"/>
        <location filename="mainwindow.ui" line="2514"/>
        <location filename="mainwindow.ui" line="3590"/>
        <source>Supprimer</source>
        <translation>Remove</translation>
    </message>
    <message>
        <source>Traduction</source>
        <translation type="vanished">Translation</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="298"/>
        <location filename="mainwindow.ui" line="2066"/>
        <location filename="mainwindow.ui" line="2885"/>
        <location filename="mainwindow.ui" line="3567"/>
        <location filename="mainwindow.ui" line="4016"/>
        <source>Statistique</source>
        <translation>Statistics</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="700"/>
        <location filename="mainwindow.ui" line="1078"/>
        <location filename="mainwindow.ui" line="2821"/>
        <location filename="mainwindow.ui" line="3474"/>
        <source>Modifier</source>
        <translation>Modify</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2527"/>
        <source>ID à supprimer :</source>
        <translation>ID to remove :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1815"/>
        <location filename="mainwindow.ui" line="2808"/>
        <location filename="mainwindow.ui" line="3107"/>
        <location filename="mainwindow.ui" line="3796"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2837"/>
        <source>BUDGET</source>
        <translation>BUDGET</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="191"/>
        <location filename="mainwindow.ui" line="2034"/>
        <location filename="mainwindow.ui" line="2922"/>
        <location filename="mainwindow.ui" line="3683"/>
        <source>Recherche</source>
        <translation>Search</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2869"/>
        <source>Nbr Client</source>
        <translation>Nbr Customers</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2853"/>
        <source>Nbr Employé</source>
        <translation>Nbr Employees</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="30"/>
        <location filename="mainwindow.ui" line="1605"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="153"/>
        <location filename="mainwindow.ui" line="1659"/>
        <source>CRUD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="165"/>
        <source>stat salaire</source>
        <translation>Stat Salary</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="207"/>
        <source>TRI SALAIRE</source>
        <translation>Sort Salary</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="220"/>
        <source>fichier pdf</source>
        <translation>File PDF</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="233"/>
        <location filename="mainwindow.ui" line="1091"/>
        <source>Afficher</source>
        <translation>Display</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="246"/>
        <source>TRI ID</source>
        <translation>SORT ID</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="259"/>
        <source>TRI NOM</source>
        <translation>SORT NAME</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="427"/>
        <source>Ajouter Employé</source>
        <translation>Add Employee</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="439"/>
        <location filename="mainwindow.ui" line="841"/>
        <location filename="mainwindow.ui" line="1746"/>
        <source>Prénom :</source>
        <translation>First Name :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="452"/>
        <location filename="mainwindow.ui" line="736"/>
        <source>Salaire :</source>
        <translation>Salary :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="465"/>
        <location filename="mainwindow.ui" line="818"/>
        <source>Agence :</source>
        <translation>Agency :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="478"/>
        <location filename="mainwindow.ui" line="713"/>
        <location filename="mainwindow.ui" line="1733"/>
        <source>Nom :</source>
        <translation>Name :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="511"/>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="534"/>
        <location filename="mainwindow.ui" line="785"/>
        <location filename="mainwindow.ui" line="996"/>
        <location filename="mainwindow.ui" line="3182"/>
        <location filename="mainwindow.ui" line="3369"/>
        <source>ID :</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="606"/>
        <location filename="mainwindow.ui" line="880"/>
        <location filename="mainwindow.ui" line="1854"/>
        <source>Sfax</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="688"/>
        <source>Modifier Employé</source>
        <translation>Update Employee</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="749"/>
        <source>Email :</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="972"/>
        <source>Autehntification</source>
        <translation>Authentication</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="984"/>
        <source>Authentification</source>
        <translation>Authentication</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1009"/>
        <source>MOT DE PASSE :</source>
        <translation>Password :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1022"/>
        <location filename="mainwindow.ui" line="1407"/>
        <source>EMAIL :</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1331"/>
        <source>LOGIN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1350"/>
        <source>your mail</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1366"/>
        <source>your mail password</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1391"/>
        <source>ImmoClick</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1423"/>
        <source>Mot de passe</source>
        <translation>Password</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1671"/>
        <source>Tri NOM</source>
        <translation>Sort Name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1721"/>
        <source>Client</source>
        <translation>Customer</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1772"/>
        <source>E-mail</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1873"/>
        <source>Etat du afficheur</source>
        <translation>Display status</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1966"/>
        <source>Supprimer un client</source>
        <translation>Remove customer</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1982"/>
        <source>Ajouter un client</source>
        <translation>Add Customer</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1995"/>
        <source>Modifier un client</source>
        <translation>Update Customer</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2008"/>
        <source>Tri PRENOM</source>
        <translation>Sort First Name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2021"/>
        <source>Tri ID</source>
        <translation>Sort ID</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2053"/>
        <source>Afficher les clients</source>
        <translation>Display Customers</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2079"/>
        <source>export excel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2186"/>
        <source>PushButton</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2206"/>
        <source>MAIL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2218"/>
        <source>Your email</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2254"/>
        <source>Message</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2267"/>
        <source>Your password</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2280"/>
        <source>Envoyer</source>
        <translation>Send</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2303"/>
        <source>PORT</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2316"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2329"/>
        <source>SMTP server</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2352"/>
        <source>Objet</source>
        <translation>Object</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2385"/>
        <source>Envoyer à</source>
        <translation>Send To</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2543"/>
        <source>Imprimer</source>
        <translation>Print</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3007"/>
        <source>Biens</source>
        <translation>Real estates</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3102"/>
        <source>Defaut</source>
        <translation>Default</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3112"/>
        <source>ADRESSE</source>
        <translation>ADRESS</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3117"/>
        <source>STATUT</source>
        <translation>STATUS</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3144"/>
        <source>Actualiser</source>
        <translation>Refresh</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3170"/>
        <source>Ajouter bien</source>
        <translation>Add Real Estate</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3205"/>
        <location filename="mainwindow.ui" line="3461"/>
        <source>Statut :</source>
        <translation>Status :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3218"/>
        <location filename="mainwindow.ui" line="3415"/>
        <source>prix :</source>
        <translation>Price :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3244"/>
        <location filename="mainwindow.ui" line="3392"/>
        <source>Categorie :</source>
        <translation>Category :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3288"/>
        <location filename="mainwindow.ui" line="3488"/>
        <source>Vendu</source>
        <translation>Sold</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3293"/>
        <location filename="mainwindow.ui" line="3493"/>
        <source>A vendre</source>
        <translation>For Sale</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3357"/>
        <source>Modifier bien</source>
        <translation>Update Real Estate</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3652"/>
        <source>Réclamations</source>
        <translation>Complaints</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3702"/>
        <source>reclmation</source>
        <translation>Complaint</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3714"/>
        <source>type:</source>
        <translation>Type :</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3727"/>
        <source>Description:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3740"/>
        <source>Date:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3753"/>
        <source>Titre:</source>
        <translation>Title:</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3919"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3935"/>
        <source>Ajouter reclamation</source>
        <translation>Add Complaint</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3951"/>
        <source>Afficher les reclamation</source>
        <translation>Display Complaint</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3964"/>
        <source>chat bot</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3977"/>
        <source>Tri</source>
        <translation>Sort</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3990"/>
        <source>notif</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4003"/>
        <source>Supprimer une reclamation</source>
        <translation>Remove Complaint</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4074"/>
        <source>Modifier reclamation</source>
        <translation>Update Complaint</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="202"/>
        <source>Excel file</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="203"/>
        <source>Excel Files (*.xls)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="220"/>
        <source>Done</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="221"/>
        <source>%1 records exported!</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="agence.cpp" line="129"/>
        <location filename="agence.cpp" line="167"/>
        <location filename="agence.cpp" line="183"/>
        <location filename="agence.cpp" line="196"/>
        <location filename="agence.cpp" line="209"/>
        <location filename="agence.cpp" line="222"/>
        <location filename="authentification.cpp" line="27"/>
        <location filename="bien.cpp" line="100"/>
        <location filename="client.cpp" line="33"/>
        <location filename="client.cpp" line="67"/>
        <location filename="client.cpp" line="79"/>
        <location filename="client.cpp" line="91"/>
        <location filename="client.cpp" line="102"/>
        <location filename="employe.cpp" line="151"/>
        <location filename="employe.cpp" line="167"/>
        <location filename="employe.cpp" line="182"/>
        <location filename="employe.cpp" line="196"/>
        <location filename="employe.cpp" line="210"/>
        <location filename="rec.cpp" line="114"/>
        <location filename="rec.cpp" line="127"/>
        <location filename="rec.cpp" line="150"/>
        <location filename="rec.cpp" line="167"/>
        <source>ID</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <location filename="agence.cpp" line="130"/>
        <source>Budget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agence.cpp" line="131"/>
        <source>Adresse</source>
        <translation>Adress</translation>
    </message>
    <message>
        <location filename="agence.cpp" line="132"/>
        <source>Nbr Employés</source>
        <translation>Nbr Employees</translation>
    </message>
    <message>
        <location filename="agence.cpp" line="133"/>
        <source>Nbr Clients</source>
        <translation>Nbr Customers</translation>
    </message>
    <message>
        <location filename="agence.cpp" line="134"/>
        <source>Nbr Biens</source>
        <translation>Nbr Real Estates</translation>
    </message>
    <message>
        <location filename="agence.cpp" line="168"/>
        <location filename="agence.cpp" line="184"/>
        <location filename="agence.cpp" line="197"/>
        <location filename="agence.cpp" line="210"/>
        <location filename="agence.cpp" line="223"/>
        <source>BUDGET</source>
        <translation type="unfinished">BUDGET</translation>
    </message>
    <message>
        <location filename="agence.cpp" line="169"/>
        <location filename="agence.cpp" line="185"/>
        <location filename="agence.cpp" line="198"/>
        <location filename="agence.cpp" line="211"/>
        <location filename="agence.cpp" line="224"/>
        <location filename="bien.cpp" line="103"/>
        <location filename="bien.cpp" line="131"/>
        <location filename="bien.cpp" line="166"/>
        <location filename="client.cpp" line="36"/>
        <location filename="client.cpp" line="70"/>
        <location filename="client.cpp" line="82"/>
        <location filename="client.cpp" line="94"/>
        <location filename="client.cpp" line="105"/>
        <location filename="employe.cpp" line="154"/>
        <location filename="employe.cpp" line="170"/>
        <location filename="employe.cpp" line="185"/>
        <location filename="employe.cpp" line="199"/>
        <location filename="employe.cpp" line="213"/>
        <source>ADRESSE</source>
        <translation>ADRESS</translation>
    </message>
    <message>
        <location filename="agence.cpp" line="170"/>
        <location filename="agence.cpp" line="186"/>
        <location filename="agence.cpp" line="199"/>
        <location filename="agence.cpp" line="212"/>
        <location filename="agence.cpp" line="225"/>
        <source>NBR_EMPLOYE</source>
        <translation>NBR_EMPLOYEES</translation>
    </message>
    <message>
        <location filename="agence.cpp" line="171"/>
        <location filename="agence.cpp" line="187"/>
        <location filename="agence.cpp" line="200"/>
        <location filename="agence.cpp" line="213"/>
        <location filename="agence.cpp" line="226"/>
        <source>NBR_CLIENT</source>
        <translation>NBR_CUSTOMERS</translation>
    </message>
    <message>
        <location filename="agence.cpp" line="172"/>
        <location filename="agence.cpp" line="188"/>
        <location filename="agence.cpp" line="201"/>
        <location filename="agence.cpp" line="214"/>
        <location filename="agence.cpp" line="227"/>
        <source>NBR_BIEN</source>
        <translation>NBR_REAL_ESTATE</translation>
    </message>
    <message>
        <location filename="main.cpp" line="29"/>
        <source>database is open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="30"/>
        <source>connection successful.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="36"/>
        <source>database is not open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="37"/>
        <source>connection failed.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="313"/>
        <location filename="mainwindow.cpp" line="317"/>
        <location filename="mainwindow.cpp" line="321"/>
        <location filename="mainwindow.cpp" line="325"/>
        <location filename="mainwindow.cpp" line="329"/>
        <location filename="mainwindow.cpp" line="333"/>
        <location filename="mainwindow.cpp" line="337"/>
        <location filename="mainwindow.cpp" line="738"/>
        <location filename="mainwindow.cpp" line="741"/>
        <location filename="mainwindow.cpp" line="744"/>
        <location filename="mainwindow.cpp" line="747"/>
        <source>not OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="314"/>
        <location filename="mainwindow.cpp" line="739"/>
        <source>Il faut saisir un ID !</source>
        <translation>You have to write an ID !</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="326"/>
        <location filename="mainwindow.cpp" line="742"/>
        <source>Il faut saisir une adresse !</source>
        <translation>You have to write an adress !</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="745"/>
        <source>Il faut saisir un budget !</source>
        <translation>You have to write a budget !</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="748"/>
        <source>Il faut saisir un nombre d&apos;employés !</source>
        <translation>You have to write a number of employees !</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="172"/>
        <location filename="mainwindow.cpp" line="176"/>
        <location filename="mainwindow.cpp" line="363"/>
        <location filename="mainwindow.cpp" line="367"/>
        <location filename="mainwindow.cpp" line="389"/>
        <location filename="mainwindow.cpp" line="393"/>
        <location filename="mainwindow.cpp" line="614"/>
        <location filename="mainwindow.cpp" line="618"/>
        <location filename="mainwindow.cpp" line="751"/>
        <location filename="mainwindow.cpp" line="784"/>
        <location filename="mainwindow.cpp" line="788"/>
        <location filename="mainwindow.cpp" line="829"/>
        <location filename="mainwindow.cpp" line="833"/>
        <location filename="mainwindow.cpp" line="1275"/>
        <location filename="mainwindow.cpp" line="1279"/>
        <source>fail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="752"/>
        <source>Agence Déja existante ! 
Click Cancel to exit.</source>
        <translation>Agency already exists ! Click Cancel to exit.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="152"/>
        <location filename="mainwindow.cpp" line="657"/>
        <location filename="mainwindow.cpp" line="760"/>
        <location filename="mainwindow.cpp" line="799"/>
        <location filename="mainwindow.cpp" line="843"/>
        <location filename="mainwindow.cpp" line="1255"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="761"/>
        <source>Ajout effectué.
Click Cancel to exit.</source>
        <translation>Add with success. Click Cancel to exit.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="158"/>
        <location filename="mainwindow.cpp" line="663"/>
        <location filename="mainwindow.cpp" line="772"/>
        <location filename="mainwindow.cpp" line="811"/>
        <location filename="mainwindow.cpp" line="855"/>
        <location filename="mainwindow.cpp" line="1261"/>
        <source>NOT OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="773"/>
        <source>Ajout non effectué.
Click Cancel to exit.</source>
        <translation>Addition not made.Click Cancel to exit.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="173"/>
        <location filename="mainwindow.cpp" line="364"/>
        <location filename="mainwindow.cpp" line="390"/>
        <location filename="mainwindow.cpp" line="615"/>
        <location filename="mainwindow.cpp" line="785"/>
        <location filename="mainwindow.cpp" line="830"/>
        <location filename="mainwindow.cpp" line="1276"/>
        <source>veuillez entrer un id.
Click Cancel to exit.</source>
        <translation>Please enter an ID.Click Cancel to exit.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="120"/>
        <location filename="mainwindow.cpp" line="187"/>
        <location filename="mainwindow.cpp" line="596"/>
        <location filename="mainwindow.cpp" line="629"/>
        <location filename="mainwindow.cpp" line="1217"/>
        <location filename="mainwindow.cpp" line="1291"/>
        <source>ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="121"/>
        <location filename="mainwindow.cpp" line="597"/>
        <location filename="mainwindow.cpp" line="1218"/>
        <source>Ajout effectué
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="126"/>
        <location filename="mainwindow.cpp" line="192"/>
        <location filename="mainwindow.cpp" line="601"/>
        <location filename="mainwindow.cpp" line="634"/>
        <location filename="mainwindow.cpp" line="1223"/>
        <source>not nok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="127"/>
        <location filename="mainwindow.cpp" line="602"/>
        <location filename="mainwindow.cpp" line="1224"/>
        <source>Ajout non effectué
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="153"/>
        <location filename="mainwindow.cpp" line="658"/>
        <source>client modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="159"/>
        <location filename="mainwindow.cpp" line="664"/>
        <source>client non modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="177"/>
        <location filename="mainwindow.cpp" line="368"/>
        <location filename="mainwindow.cpp" line="394"/>
        <source>employee n&apos;existe pas.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="188"/>
        <location filename="mainwindow.cpp" line="630"/>
        <location filename="mainwindow.cpp" line="1292"/>
        <source>Suppression effectué
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="193"/>
        <location filename="mainwindow.cpp" line="635"/>
        <location filename="mainwindow.cpp" line="1297"/>
        <source>Suppression non effectué
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="293"/>
        <location filename="mainwindow.cpp" line="345"/>
        <location filename="mainwindow.cpp" line="379"/>
        <location filename="mainwindow.cpp" line="405"/>
        <location filename="mainwindow.cpp" line="694"/>
        <location filename="mainwindow.cpp" line="708"/>
        <location filename="mainwindow.cpp" line="1162"/>
        <location filename="mainwindow.cpp" line="1169"/>
        <source>Succès</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="294"/>
        <source>Le mail a été envoyé avec succès.
Cliquer sur Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="318"/>
        <source>Il faut saisir un nom !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="322"/>
        <source>Il faut saisir un prenom !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="330"/>
        <source>Il faut saisir un email !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="334"/>
        <source>Il faut saisir une reference !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="338"/>
        <source>Il faut saisir un salaire !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="346"/>
        <source>employe ajouté avec succès.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="380"/>
        <location filename="mainwindow.cpp" line="406"/>
        <source>Employé supprimé avec succès.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="619"/>
        <source>authen n&apos;existe pas.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="695"/>
        <source>Alarme éteinte ! 
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="709"/>
        <source>Connexion avec succées ! LED VERTE allumée pendant 2s 
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="789"/>
        <location filename="mainwindow.cpp" line="834"/>
        <source>Agence n&apos;existe pas.
Click Cancel to exit.</source>
        <translation>Agency does not exist ! Click Cancel to exit.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="800"/>
        <source>Suppression effectuée.
Click Cancel to exit.</source>
        <translation>Deletion made.Click Cancel to exit.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="812"/>
        <source>Suppression non effectué.
Click Cancel to exit.</source>
        <translation>Deetion not made.Click Cancel to exit.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="844"/>
        <source>agence modifié.
Click Cancel to exit.</source>
        <translation>Agency updated.Click Cancel to exit.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="856"/>
        <source>agence non modifié.
Click Cancel to exit.</source>
        <translation>Agency not updated.Click Cancel to exit.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="967"/>
        <location filename="mainwindow.cpp" line="975"/>
        <source>Echèc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="968"/>
        <location filename="mainwindow.cpp" line="976"/>
        <source>Mot de passe ou email non valide.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1086"/>
        <source>SuccÃ¨s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1087"/>
        <source>Bien supprimÃ© avec succÃ¨s.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1163"/>
        <source>Bien ajout avec succès.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1170"/>
        <source>Bien non ajouter.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1256"/>
        <source>reclamation modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1262"/>
        <source>reclamation non modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1280"/>
        <source>reclamation n&apos;existe pas.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1296"/>
        <source>not ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1325"/>
        <source>IMPORTANT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1326"/>
        <source>VOUS AVEZ UNE RECLAMATION
Click Cancel POUR L&apos;AFFICHER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1330"/>
        <source>RIEN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1331"/>
        <source>VOUS N&apos;AVEZ PAS DE NOUVELLE RECLAMATION
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="authentification.cpp" line="28"/>
        <location filename="client.cpp" line="37"/>
        <location filename="client.cpp" line="71"/>
        <location filename="client.cpp" line="83"/>
        <location filename="client.cpp" line="95"/>
        <location filename="client.cpp" line="106"/>
        <location filename="employe.cpp" line="155"/>
        <location filename="employe.cpp" line="171"/>
        <location filename="employe.cpp" line="186"/>
        <location filename="employe.cpp" line="200"/>
        <location filename="employe.cpp" line="214"/>
        <source>EMAIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="authentification.cpp" line="29"/>
        <source>MDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bien.cpp" line="101"/>
        <location filename="bien.cpp" line="129"/>
        <location filename="bien.cpp" line="164"/>
        <source>CATEGORIE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bien.cpp" line="102"/>
        <source>PRIX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bien.cpp" line="104"/>
        <location filename="bien.cpp" line="132"/>
        <location filename="bien.cpp" line="167"/>
        <source>STATUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bien.cpp" line="128"/>
        <location filename="bien.cpp" line="163"/>
        <source>ID </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bien.cpp" line="130"/>
        <location filename="bien.cpp" line="165"/>
        <source>PRIX </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="client.cpp" line="34"/>
        <location filename="client.cpp" line="68"/>
        <location filename="client.cpp" line="80"/>
        <location filename="client.cpp" line="92"/>
        <location filename="client.cpp" line="103"/>
        <location filename="employe.cpp" line="152"/>
        <location filename="employe.cpp" line="168"/>
        <location filename="employe.cpp" line="183"/>
        <location filename="employe.cpp" line="197"/>
        <location filename="employe.cpp" line="211"/>
        <source>NOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="client.cpp" line="35"/>
        <location filename="client.cpp" line="69"/>
        <location filename="client.cpp" line="81"/>
        <location filename="client.cpp" line="93"/>
        <location filename="client.cpp" line="104"/>
        <location filename="employe.cpp" line="153"/>
        <location filename="employe.cpp" line="169"/>
        <location filename="employe.cpp" line="184"/>
        <location filename="employe.cpp" line="198"/>
        <location filename="employe.cpp" line="212"/>
        <source>PRENOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="employe.cpp" line="156"/>
        <location filename="employe.cpp" line="172"/>
        <location filename="employe.cpp" line="187"/>
        <location filename="employe.cpp" line="201"/>
        <location filename="employe.cpp" line="215"/>
        <source>SALAIRE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="employe.cpp" line="157"/>
        <location filename="employe.cpp" line="173"/>
        <location filename="employe.cpp" line="188"/>
        <location filename="employe.cpp" line="202"/>
        <location filename="employe.cpp" line="216"/>
        <source>AGENCE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rec.cpp" line="92"/>
        <source>date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rec.cpp" line="93"/>
        <source>description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rec.cpp" line="94"/>
        <source>titre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rec.cpp" line="95"/>
        <source>type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rec.cpp" line="96"/>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rec.cpp" line="110"/>
        <location filename="rec.cpp" line="123"/>
        <location filename="rec.cpp" line="146"/>
        <location filename="rec.cpp" line="163"/>
        <source>DATE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rec.cpp" line="111"/>
        <location filename="rec.cpp" line="124"/>
        <location filename="rec.cpp" line="147"/>
        <location filename="rec.cpp" line="164"/>
        <source>DESCRIPTION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rec.cpp" line="112"/>
        <location filename="rec.cpp" line="125"/>
        <location filename="rec.cpp" line="148"/>
        <location filename="rec.cpp" line="165"/>
        <source>TITRE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rec.cpp" line="113"/>
        <location filename="rec.cpp" line="126"/>
        <location filename="rec.cpp" line="149"/>
        <location filename="rec.cpp" line="166"/>
        <source>TYPE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Smtp</name>
    <message>
        <location filename="smtp.cpp" line="194"/>
        <source>Message sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtp.cpp" line="204"/>
        <source>Qt Simple SMTP client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtp.cpp" line="204"/>
        <source>Unexpected reply from SMTP server:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smtp.cpp" line="206"/>
        <source>Failed to send message</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>statistique</name>
    <message>
        <location filename="statistique.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statistique</source>
        <translation type="vanished">Statistics</translation>
    </message>
    <message>
        <source>Pourcentage</source>
        <translation type="vanished">percentage</translation>
    </message>
</context>
<context>
    <name>statistique_age</name>
    <message>
        <location filename="statistique_age.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_age.ui" line="30"/>
        <source>Statistique</source>
        <translation type="unfinished">Statistics</translation>
    </message>
    <message>
        <location filename="statistique_age.ui" line="46"/>
        <source>Nabeul</source>
        <translation type="unfinished">Nabeul</translation>
    </message>
    <message>
        <location filename="statistique_age.ui" line="129"/>
        <source>Bizerte</source>
        <translation type="unfinished">Bizerte</translation>
    </message>
    <message>
        <location filename="statistique_age.ui" line="145"/>
        <source>Manouba</source>
        <translation type="unfinished">Manouba</translation>
    </message>
    <message>
        <location filename="statistique_age.ui" line="161"/>
        <source>Sousse</source>
        <translation type="unfinished">Sousse</translation>
    </message>
    <message>
        <location filename="statistique_age.ui" line="177"/>
        <source>Pourcentage</source>
        <translation type="unfinished">percentage</translation>
    </message>
    <message>
        <location filename="statistique_age.ui" line="193"/>
        <source>Tunis</source>
        <translation type="unfinished">Tunis</translation>
    </message>
</context>
<context>
    <name>statistique_cl</name>
    <message>
        <location filename="statistique_cl.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_cl.ui" line="30"/>
        <source> statistique d&apos;Adresse </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_cl.ui" line="59"/>
        <source>Tunis</source>
        <translation type="unfinished">Tunis</translation>
    </message>
    <message>
        <location filename="statistique_cl.ui" line="75"/>
        <source>Bizerte</source>
        <translation type="unfinished">Bizerte</translation>
    </message>
    <message>
        <location filename="statistique_cl.ui" line="91"/>
        <source>Pourcentage</source>
        <translation type="unfinished">percentage</translation>
    </message>
    <message>
        <location filename="statistique_cl.ui" line="134"/>
        <source>Sfax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_cl.ui" line="150"/>
        <source>Nabeul</source>
        <translation type="unfinished">Nabeul</translation>
    </message>
    <message>
        <location filename="statistique_cl.ui" line="166"/>
        <source>Sousse</source>
        <translation type="unfinished">Sousse</translation>
    </message>
</context>
<context>
    <name>statistique_em</name>
    <message>
        <location filename="statistique_em.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_em.ui" line="29"/>
        <source>Pourcentage</source>
        <translation type="unfinished">percentage</translation>
    </message>
    <message>
        <location filename="statistique_em.ui" line="59"/>
        <source>Sfax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_em.ui" line="88"/>
        <source>Sousse</source>
        <translation type="unfinished">Sousse</translation>
    </message>
    <message>
        <location filename="statistique_em.ui" line="105"/>
        <source> statistique d&apos;Adresse </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_em.ui" line="148"/>
        <source>Bizerte</source>
        <translation type="unfinished">Bizerte</translation>
    </message>
    <message>
        <location filename="statistique_em.ui" line="164"/>
        <source>Nabeul</source>
        <translation type="unfinished">Nabeul</translation>
    </message>
    <message>
        <location filename="statistique_em.ui" line="193"/>
        <source>Tunis</source>
        <translation type="unfinished">Tunis</translation>
    </message>
</context>
<context>
    <name>statistique_rec</name>
    <message>
        <location filename="statistique_rec.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_rec.ui" line="29"/>
        <source>employe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_rec.ui" line="72"/>
        <source>Pourcentage</source>
        <translation type="unfinished">percentage</translation>
    </message>
    <message>
        <location filename="statistique_rec.ui" line="89"/>
        <source>Statistique </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistique_rec.ui" line="105"/>
        <source>client</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>statistiques</name>
    <message>
        <location filename="statistiques.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistiques.ui" line="58"/>
        <location filename="statistiques.ui" line="91"/>
        <location filename="statistiques.ui" line="123"/>
        <location filename="statistiques.ui" line="165"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistiques.ui" line="75"/>
        <source>Statistique par  salaire_Employee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistiques.ui" line="107"/>
        <source>Pourcentage</source>
        <translation type="unfinished">percentage</translation>
    </message>
    <message>
        <location filename="statistiques.ui" line="136"/>
        <location filename="statistiques.ui" line="149"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="statistiques.ui" line="204"/>
        <source>PushButton</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
