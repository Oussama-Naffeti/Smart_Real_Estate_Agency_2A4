#include "statistique_cl.h"
#include "ui_statistique_cl.h"
#include "ui_mainwindow.h"
#include<iostream>
#include "mainwindow.h"


statistique_cl::statistique_cl(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::statistique_cl)
{
    ui->setupUi(this);
}

statistique_cl::~statistique_cl()
{
    delete ui;
}
int statistique_cl::statistique_cl_partie2()
{
    QSqlQuery query;
    int count=0 ;
    QSqlQuery requete("select * from client where adresse_client = 'Bizerte'") ;
    while(requete.next())
    {
            count++ ;
    }

return count ;
}

int statistique_cl::statistique_cl_partie3()
{
    QSqlQuery query;
    int count=0 ;
    QSqlQuery requete("select * from client where adresse_client = 'Tunis'") ;
    while(requete.next())
    {
            count++ ;
    }

return count ;
}
int statistique_cl::statistique_cl_partie4()
{
    QSqlQuery query;
    int count=0 ;
    QSqlQuery requete("select * from client where adresse_client = 'Nabeul'") ;
    while(requete.next())
    {
            count++ ;
    }

return count ;
}
int statistique_cl::statistique_cl_partie5()
{
    QSqlQuery query;
    int count=0 ;
    QSqlQuery requete("select * from client where adresse_client = 'Sfax'") ;
    while(requete.next())
    {
            count++ ;
    }

return count ;
}
int statistique_cl::statistique_cl_partie6()
{
    QSqlQuery query;
    int count=0 ;
    QSqlQuery requete("select * from client where adresse_client = Sousse") ;
    while(requete.next())
    {
            count++ ;
    }

return count ;
}

void statistique_cl::paintEvent(QPaintEvent *)
{

    int b=statistique_cl_partie2();
    cout<<b<<endl ;
    int c=statistique_cl_partie3();
    cout<<c<<endl ;
    int d=statistique_cl_partie4();
    cout<<c<<endl ;
    int e=statistique_cl_partie5();
    cout<<c<<endl ;
    int f=statistique_cl_partie6();
    cout<<c<<endl ;


        float s2= b*100 ;
        float s3=c*100;
        float s4=d*100;
        float s5=e*100;
        float s6=f*100;
        float nb = b+c+d+e+f ;
        float q2 ;
        q2 = s2/nb ;
        float q3;
        q3=s3/nb;
        float q4;
        q4=s4/nb;
        float q5;
        q5=s5/nb;
        float q6;
        q6=s6/nb;
        float y  ;
        y = (q2*360)/100 ;
        float m;
        m= (q3*360)/100;
        float p;
        p= (q4*360)/100;
        float v;
        v= (q5*360)/100;
        float w;
        w= (q6*360)/100;
    QPainter painter(this);
    QRectF size=QRectF(150,40,this->width()-600,this->width()-600);

    painter.setBrush(Qt::blue);
    painter.drawPie(size,0,16*y);
    ui->label_2->setText("Bizerte") ;
    painter.setBrush(Qt::green);
    painter.drawPie(size,16*y,16*m);
    painter.setBrush(Qt::black);
    painter.drawPie(size,16*(m+y),16*p);
    painter.setBrush(Qt::yellow);
    painter.drawPie(size,16*(m+y+p),16*v);
    painter.setBrush(Qt::red);
    painter.drawPie(size,16*(m+y+p+v),16*w);


}
