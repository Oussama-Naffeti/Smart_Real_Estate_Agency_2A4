#include "statistique.h"
#include "ui_statistique.h"
#include <QString>
statistique::statistique(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::statistique)
{
    ui->setupUi(this);
}

statistique::~statistique()
{
    delete ui;
}
void statistique::make()
{
        int oui;
        int non;
        int total;
        QString oui_res;
        QString non_res;
        QSqlQuery q;

        q.prepare("SELECT COUNT(ID) FROM BIEN where STATUT='vendu'");
        q.exec();
        q.first() ;
        oui=(q.value(0).toInt());

        q.prepare("SELECT COUNT(ID) FROM BIEN where STATUT='a vendre'");
        q.exec();
        q.first() ;
        non=(q.value(0).toInt());
        q.prepare("SELECT COUNT(ID) FROM BIEN  ");
        q.exec();
        q.first() ;
        total=(q.value(0).toInt());

        oui=((double)oui/(double)total)*100;
        non=100-oui;

        oui_res= QString::number(oui);
        non_res=QString::number(non);
        QPieSeries *series;
         series= new  QPieSeries();
         series->append("Vendu"+oui_res+"%",oui);
         series->append("NON Vendu"+non_res+"%",non);
         QPieSlice *slice0 = series->slices().at(0);
          slice0->setLabelVisible();

          QPieSlice *slice1 = series->slices().at(1);
             slice1->setExploded();
             slice1->setLabelVisible();
             slice1->setPen(QPen(Qt::green, 3));
             slice1->setBrush(Qt::darkYellow);

              QChart *chart = new QChart();
              chart->addSeries(series);
              chart->setTitle("Stat sur Les biens vendu ou non vendus ");
              chart->legend()->show();
              QChartView *chartView = new QChartView(chart);
              chartView->setRenderHint(QPainter::Antialiasing);
              ui->verticalLayout->addWidget(chartView);

}
