#ifndef REC_H
#define REC_H


#include<QString>
#include<QSqlQuery>
#include<QSqlQueryModel>
#include <QSqlDatabase>
#include <QSqlError>


class recl
{
    QString type,date,titre,description;
    int id;


public:
    //constructeur
    recl();
    recl(int,QString,QString,QString,QString);
    //getters
    int getID(){return id;}
    QString getDate(){return date;}
    QString getTitre(){return titre;}
    QString getDescription(){return description;}
    QString getType(){return type;}



    //setters
    void setDate(QString d){date=d;}
    void setTitre(QString t){titre=t;}
    void setDescription(QString de){description=de;}
    void setID(int id){this->id=id;}
void setType(QString ty){type=ty;}


    //fonction crud
    bool ajouter();
    bool update(int id);

    QSqlQueryModel* afficher();
    bool supprimer(int);
    //metier
    QSqlQueryModel * recherche(QString);
    QSqlQueryModel * triParId();
    QSqlQueryModel * triParType();
    QSqlQueryModel * triParType1();


    bool recExist(int id);

};

#endif // REC_H
