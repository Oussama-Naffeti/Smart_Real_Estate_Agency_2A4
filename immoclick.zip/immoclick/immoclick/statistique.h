#ifndef STATISTIQUE_H
#define STATISTIQUE_H
#include<QtCharts>
#include<QChartView>
#include<QPieSeries>
#include<QPieSlice>
#include <QWidget>
#include <QSqlQuery>

namespace Ui {
class statistique;
}

class statistique : public QWidget
{
    Q_OBJECT

public:
    explicit statistique(QWidget *parent = nullptr);
       void make();
    ~statistique();


private:
    Ui::statistique *ui;
};

#endif // STATISTIQUE_H
