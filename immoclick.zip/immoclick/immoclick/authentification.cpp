#include "authentification.h"
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QObject>
authentification::authentification(int id, QString email,QString mdp)
{
    this->id=id;
    this->email=email;
    this->mdp=mdp;
}
bool authentification::ajouter()
{
    QSqlQuery query;
    QString res = QString::number(id);
    query.prepare("INSERT INTO AUTHENTIFICATION (id, email ,mdp)" "VALUES (:id, :email, :mdp)");
    //creation des variable
    query.bindValue(":id",res);
    query.bindValue(":email",email);
    query.bindValue(":mdp",mdp);
    return query.exec(); //execute
}
QSqlQueryModel * authentification::afficher()
{
    QSqlQueryModel * model=new QSqlQueryModel();
    model->setQuery("SELECT * FROM AUTHENTIFICATION");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("EMAIL"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("MDP"));
    return model;
}
bool authentification::supprimer(int id)
{
    QSqlQuery query;
    QString res=QString::number(id);
    query.prepare("Delete from AUTHENTIFICATION where id= :id");
    query.bindValue(":id",res);
    return query.exec();
}
bool authentification::modifier(int id)
{
    QSqlQuery query;
    QString res = QString::number(id);
    query.prepare("UPDATE AUTHENTIFICATION SET email= :email ,mdp= :mdp WHERE id= :id");
    query.bindValue(":id",res);
    query.bindValue(":email",email);
    query.bindValue(":mdp",mdp);
    return query.exec();
}
bool authentification::authentificationExist(int id){
    QSqlQueryModel * model= new QSqlQueryModel();
    QString res= QString::number(id);
    model->setQuery("select * from AUTHENTIFICATION WHERE id="+res);
    return  model->rowCount();
}
