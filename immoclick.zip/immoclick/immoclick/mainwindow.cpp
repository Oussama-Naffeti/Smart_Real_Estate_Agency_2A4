#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "client.h"
#include <QMessageBox>
#include <QIntValidator>
#include <QFileDialog>
#include <QtCharts/QBarSeries>
#include "statistique_cl.h"
#include "statistiques.h"
#include "smtp.h"
#include "arduino.h"
#include "employe.h"
#include <QDebug>
#include <QIntValidator>
#include "connection.h"
#include <QPrinter>
#include <QPrintDialog>
#include <QTextDocument>
#include <QDate>
#include "qrcodegen.hpp"
#include <QDateTime>
#include"statistique_em.h"
#include "statistique_age.h"

#include "agence.h"
#include"historique.h"
#include"statistique.h"
#include "statistique_rec.h"
#include <QTime>

#include <QtPrintSupport/QPrinter>
#include <QtPrintSupport/qprinter.h>
#include <QtPrintSupport/QPrintDialog>
#include <QtPrintSupport/qprintdialog.h>

#include "bien.h"

#include <QTranslator>
#include <qtranslator.h>
using std::uint8_t;
using qrcodegen::QrCode;
using qrcodegen::QrSegment;
int erreur=0; /* erreur arduino */

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tableau->setModel(cl.afficher());
    ui->server->setText("smtp.gmail.com");
    ui->port->setText("465");
//employe
    ui->tab_emp->setModel(e.afficher());
     ui->tableau_2->setModel(auth.afficher());
     int ret=A.connect_arduino(); // lancer la connexion à arduino
     switch(ret){
     case(0):qDebug()<< "arduino is available and connected to : "<< A.getarduino_port_name();
         break;
     case(1):qDebug() << "arduino is available but not connected to :" <<A.getarduino_port_name();
        break;
     case(-1):qDebug() << "arduino is not available";
     }
      QObject::connect(A.getserial(),SIGNAL(readyRead()),this,SLOT(update_label())); // permet de lancer
      //le slot update_label suite à la reception du signal readyRead (reception des données).
      //agence
      ui->tableView->setModel(Etmp.afficher());
  //bien
      ui->tab_bien_2->setModel(b.afficher());

      timer = new QTimer(this);
      timer = new QTimer(this);
      connect(timer, SIGNAL(timeout()),this,SLOT(myfunction()));
              timer->start(1000);
              QDate date =  QDate::currentDate();
   ui->label_16->setText(date.toString());
   //rec
   ui->tableaurec->setModel(r.afficher());

   //int ret=A.connect_arduino(); // lancer la connexion à arduino
      switch(ret){
      case(0):qDebug()<< "arduino is available and connected to : "<< A.getarduino_port_name();
          break;
      case(1):qDebug() << "arduino is available but not connected to :" <<A.getarduino_port_name();
         break;
      case(-1):qDebug() << "arduino is not available";
      }
       QObject::connect(A.getserial(),SIGNAL(readyRead()),this,SLOT(update_label())); // permet de lancer
       //le slot update_label suite à la reception du signal readyRead (reception des données).




}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_ajouterclient_clicked()
{
    if (controlSaisie_client())
    {
     //recuperation des informations
     int id=ui->lineEditID->text().toInt();
     ui->lineEditID->clear();
     QString nom=ui->linenom->text();
     ui->linenom->clear();
     QString prenom=ui->lineEdit_prenom->text();
     ui->lineEdit_prenom->clear();
     QString adresse_client=ui->lineEdit_ad->currentText();
     QString email_client=ui->lineEdit_email->text();
     ui->lineEdit_email->clear();
     client c(id,nom,prenom,adresse_client,email_client);
     bool test=c.ajouter();
      ui->tableau->setModel(cl.afficher());
     if(test)
     {
         QMessageBox::information(nullptr, QObject::tr("ok"),
                                  QObject::tr("Ajout effectué\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

     }
    }else
         QMessageBox::critical(nullptr, QObject::tr("not nok"),
                                QObject::tr("Ajout non effectué\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_modifierclient_clicked()
{

    if (controlSaisie_client()){
    //modifier les valeur de class
    int id=ui->lineEditID->text().toInt();
    ui->lineEditID->clear();
    QString nom=ui->linenom->text();
    ui->linenom->clear();
    QString prenom=ui->lineEdit_prenom->text();
    ui->lineEdit_prenom->clear();
    QString adresse_client=ui->lineEdit_ad->currentText();

    QString email_client=ui->lineEdit_email->text();
    ui->lineEdit_email->clear();
    client cl(id,nom,prenom,adresse_client,email_client);

bool test = cl.modifier(id);
if(test)
{
    ui->tableau->setModel(cl.afficher());
    QMessageBox::information(nullptr, QObject::tr("OK"),
                QObject::tr("client modifié.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}
    }else
    QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                QObject::tr("client non modifié.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_afficherclient_clicked()
{
     ui->tableau->setModel(cl.afficher());
}

void MainWindow::on_supprimerclient_clicked()
{
    if (ui->lineEditID->text().isEmpty())
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("veuillez entrer un id.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else if (cl.clientExist(ui->lineEditID->text().toInt())==0)
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("employee n'existe pas.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else {
    int id=ui->lineEditID->text().toInt();
    ui->lineEditID->clear();
    bool test=cl.supprimer(id);

    ui->tableau->setModel(cl.afficher());
    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("ok"),
                                 QObject::tr("Suppression effectué\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else {
        QMessageBox::critical(nullptr, QObject::tr("not nok"),
                               QObject::tr("Suppression non effectué\n"
                                           "Click Cancel to exit."), QMessageBox::Cancel);
    }
    }
}

void MainWindow::on_export_excel_clicked()
{

    QString fileName = QFileDialog::getSaveFileName(this, tr("Excel file"), qApp->applicationDirPath (),
                                                       tr("Excel Files (*.xls)"));
       if (fileName.isEmpty())
           return;

       ExportExcelObject obj(fileName, "mydata", ui->tableau);

       //colums to export
       obj.addField(0, "id", "char(20)");
       obj.addField(1, "nom", "char(20)");
       obj.addField(2, "prenom", "char(20)");
       obj.addField(3, "adresse_client", "char(20)");
       obj.addField(4, "email_client", "char(20)");


       int retVal = obj.export2Excel();
       if( retVal > 0)
       {
           QMessageBox::information(this, tr("Done"),
                                    QString(tr("%1 records exported!")).arg(retVal)
                                    );
       }
}

void MainWindow::on_statistiqueclient_clicked()
{
    statistique_cl scl;
    scl.exec();
}

void MainWindow::on_tri_idclient_clicked()
{
     ui->tableau->setModel(cl.triParId());
}

void MainWindow::on_trinomclient_clicked()
{
    ui->tableau->setModel(cl.triParNOM());
}

void MainWindow::on_triprenomclient_clicked()
{
    ui->tableau->setModel(cl.triParPRENOM());
}


bool MainWindow::controlSaisie_client(){
    QRegExp mailREX("\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b");
    mailREX.setCaseSensitivity(Qt::CaseInsensitive);
    mailREX.setPatternSyntax(QRegExp::RegExp);

    if (
            !(ui->linenom->text().contains(QRegExp("^[A-Za-z]+$"))) ||

            !(ui->lineEdit_prenom->text().contains(QRegExp("^[A-Za-z]+$"))) ||

            !(mailREX.exactMatch(ui->lineEdit_email->text())) )
        return 0;
    else
        return 1;
}

void MainWindow::update_label()
{
    data=A.read_from_arduino();

    if(data=="1")

        ui->label_14->setText("ON"); // si les données reçues de arduino via la liaison série sont égales à 1
    // alors afficher ON

    else if (data=="0")

        ui->label_14->setText("OFF");   // si les données reçues de arduino via la liaison série sont égales à 0
     //alors afficher ON
}

void MainWindow::on_rechercher_textChanged()
{
    QString rech=ui->rechercher->text();
    ui->tableau->setModel(cl.recherche(rech));
}

void MainWindow::on_sendBtn_clicked()
{
    Smtp* smtp = new Smtp(ui->uname->text(), ui->paswd->text(), ui->server->text(), ui->port->text().toInt());
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));


    smtp->sendMail(ui->uname->text(), ui->rcpt->text() , ui->subject->text(),ui->msg->toPlainText());

    QMessageBox::information(nullptr, QObject::tr("Succès"),
                QObject::tr("Le mail a été envoyé avec succès.\n"
                            "Cliquer sur Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_ajouteremployer_clicked()
{
      int id = ui->id->text().toInt();
    QString nom = ui->nom->text();
        QString prenom = ui->prenom->text();
        QString adresse = ui->adresse->currentText();
        QString email =ui->email->text();
        double salaire = ui->salaire->text().toDouble();
        QString ref_agence = ui->ref_agence->text();


        Employe e(id,nom,prenom,adresse,email,ref_agence,salaire);

        if (id == NULL) {
                    QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                          QObject::tr("Il faut saisir un ID !"), QMessageBox::Cancel);
                }
        else if (nom == NULL) {
                    QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                          QObject::tr("Il faut saisir un nom !"), QMessageBox::Cancel);
                }
        else if (prenom== NULL) {
                    QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                          QObject::tr("Il faut saisir un prenom !"), QMessageBox::Cancel);
                }
        else if (adresse == NULL) {
                    QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                          QObject::tr("Il faut saisir une adresse !"), QMessageBox::Cancel);
                }
        else if (email== NULL) {
                    QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                          QObject::tr("Il faut saisir un email !"), QMessageBox::Cancel);
                }
        else if (ref_agence == NULL) {
                    QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                          QObject::tr("Il faut saisir une reference !"), QMessageBox::Cancel);
                }
        else if (salaire == NULL) {
                    QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                          QObject::tr("Il faut saisir un salaire !"), QMessageBox::Cancel);
                }

        else {
            bool test=e.ajouter();
            if (test)
            {
                QMessageBox::information(nullptr, QObject::tr("Succès"),
                            QObject::tr("employe ajouté avec succès.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
                 ui->tab_emp->setModel(e.afficher());
            }
    }

}

void MainWindow::on_afficher_employer_clicked()
{
    ui->tab_emp->setModel(e.afficher());
}

void MainWindow::on_supprimer_employer_clicked()
{
    Employe e1;
    if (ui->id_supp->text().isEmpty())
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("veuillez entrer un id.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else if (e1.employeExist(ui->id_supp->text().toInt())==0)
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("employee n'existe pas.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else {
    e1.set_id(ui->id_supp->text().toInt());


       bool test=e1.supprimer(e1.get_id());

       if (test)
       {
          ui->tab_emp->setModel(e1.afficher());
           QMessageBox::information(nullptr, QObject::tr("Succès"),
                       QObject::tr("Employé supprimé avec succès.\n"
                                   "Click Cancel to exit."), QMessageBox::Cancel);
       }}
}

void MainWindow::on_modifier_emp_clicked()
{
    Employe e1;
    if (ui->id_supp->text().isEmpty())
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("veuillez entrer un id.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else if (e1.employeExist(ui->id_supp->text().toInt())==0)
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("employee n'existe pas.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else {
    e1.set_id(ui->id_supp->text().toInt());


       bool test=e1.supprimer(e1.get_id());

       if (test)
       {
          ui->tab_emp->setModel(e1.afficher());
           QMessageBox::information(nullptr, QObject::tr("Succès"),
                       QObject::tr("Employé supprimé avec succès.\n"
                                   "Click Cancel to exit."), QMessageBox::Cancel);
       }}
}

void MainWindow::on_qrcode_clicked()
{
    /*QString text="Gestion Employe";
        QrCode qr = QrCode::encodeText( text.toUtf8().data(), QrCode::Ecc::MEDIUM );
                  qint32 sz = qr.getSize();
                  QImage im(sz,sz, QImage::Format_RGB32);
                    QRgb black = qRgb(  0,  0,  0);
                    QRgb white = qRgb(255,255,255);
                  for (int y = 0; y < sz; y++)
                    for (int x = 0; x < sz; x++)
                      im.setPixel(x,y,qr.getModule(x, y) ? black : white );
                  ui->qrCode->setPixmap( QPixmap::fromImage(im.scaled(256,256,Qt::KeepAspectRatio,Qt::FastTransformation),Qt::MonoOnly) );

*/

}

bool MainWindow::controlSaisie(){
    QRegExp mailREX("\b[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}\b");
        mailREX.setCaseSensitivity(Qt::CaseInsensitive);
        mailREX.setPatternSyntax(QRegExp::RegExp);

        if (
                !(ui->nom->text().contains(QRegExp("^[A-Za-z]+$"))) ||

                !(ui->prenom->text().contains(QRegExp("^[A-Za-z]+$"))) ||

                !(ui->adresse->currentText().contains(QRegExp("^[A-Za-z]+$"))) ||

                !(ui->ref_agence->text().contains(QRegExp("^[A-Za-z]+$"))) ||

        !(ui->salaire->text().contains(QRegExp("^[ 0 - 454646]+$"))) ||

                !(mailREX.exactMatch(ui->email->text())) )
            return 0;
        else
            return 1;
}

void MainWindow::on_pdfemp_clicked()
{
    QString strStream;
                QTextStream out(&strStream);

                const int rowCount = ui->tab_emp->model()->rowCount();
                const int columnCount = ui->tab_emp->model()->columnCount();
                QString TT = QDate::currentDate().toString("yyyy/MM/dd");
                out <<"<html>\n"
                      "<head>\n"
                       "<meta Content=\"Text/html; charset=Windows-1251\">\n"
                    << "<title> LISTE DES PRODUITS<title>\n "
                    << "</head>\n"
                    "<body bgcolor=#ffffff link=#5000A0>\n"
                    "<h1 style=\"text-align: center;\"><strong> **LISTE DES EMPLOYES ** "+TT+"</strong></h1>"
                    "<table style=\"text-align: center; font-size: 20px;\" border=1>\n "
                      "</br> </br>";
                // headers
                out << "<thead><tr bgcolor=#d6e5ff>";
                for (int column = 0; column < columnCount; column++)
                    if (!ui->tab_emp->isColumnHidden(column))
                        out << QString("<th>%1</th>").arg(ui->tab_emp->model()->headerData(column, Qt::Horizontal).toString());
                out << "</tr></thead>\n";

                // data table
                for (int row = 0; row < rowCount; row++) {
                    out << "<tr>";
                    for (int column = 0; column < columnCount; column++) {
                        if (!ui->tab_emp->isColumnHidden(column)) {
                            QString data =ui->tab_emp->model()->data(ui->tab_emp->model()->index(row, column)).toString().simplified();
                            out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
                        }
                    }
                    out << "</tr>\n";
                }
                out <<  "</table>\n"
                    "</body>\n"
                    "</html>\n";

                QTextDocument *document = new QTextDocument();
                document->setHtml(strStream);

                QPrinter printer;

                /*QPrintDialog *test = new QPrintDialog(&printer, NULL);
                if (test->exec() == QDialog::Accepted) {
                    document->print(&printer);
                }

                delete document;*/
}

void MainWindow::on_statistique_employer_clicked()
{
    statistique_em semp;
    semp.exec();
}

void MainWindow::on_stat_salaire_emp_clicked()
{
    statistiques s;
    s.exec();
}

void MainWindow::on_rechercher_emp_textChanged()
{
    QString rech=ui->rechercher->text();
        ui->tab_emp->setModel(e.rechercher(rech));
}

void MainWindow::on_tri_salaireemp_clicked()
{
    ui->tab_emp->setModel(e.triS());
}

void MainWindow::on_tri_nom_emp_clicked()
{
    ui->tab_emp->setModel(e.triN());
}


void MainWindow::on_tab_emp_clicked(const QModelIndex &index)
{
    int tabeq=ui->tab_emp->currentIndex().row();
      QVariant idd=ui->tab_emp->model()->data(ui->tab_emp->model()->index(tabeq,0));
      QString idf=idd.toString();
     // QString code=idd.toSTring();
      QSqlQuery qry;
      qry.prepare("select * from employe where ID=:ID");
      qry.bindValue(":ID",idf);
      qry.exec();

       QString nom,prenom,adresse_employe,email_employe, salaire_employe,ref_employe;//attributs
       //int idf;


     while(qry.next()){

          idf=qry.value(0).toString();
          nom=qry.value(1).toString();
          prenom=qry.value(2).toString();
          adresse_employe=qry.value(3).toString();
         email_employe=qry.value(4).toString();
        salaire_employe=qry.value(5).toString();
          ref_employe=qry.value(6).toString();



      }
      idf=QString(idf);
     //QString text = idf ;
             idf="ID:\t" +idf+ " Nom\t:" +nom+ " Prenom:\t" +prenom+ + " Adresse:\t" +adresse_employe+ " email:\t" +email_employe+ " salaire:\t" +salaire_employe+ " referance:\t" +ref_employe ;
      qrcodegen::QrCode qr = qrcodegen::QrCode::encodeText(idf.toUtf8().constData(), qrcodegen::QrCode::Ecc::HIGH);

      // Read the black & white pixels
      QImage im(qr.getSize(),qr.getSize(), QImage::Format_RGB888);
      for (int y = 0; y < qr.getSize(); y++) {
          for (int x = 0; x < qr.getSize(); x++) {
              int color = qr.getModule(x, y);  // 0 for white, 1 for black

              // You need to modify this part
              if(color==0)
                  im.setPixel(x, y,qRgb(254, 254, 254));
              else
                  im.setPixel(x, y,qRgb(0, 0, 0));
          }
      }
      im=im.scaled(200,200);
                ui->qrcodeLabel->setPixmap(QPixmap::fromImage(im));
}
void MainWindow::on_Ajouter_clicked()
{
    if (controlSaisie1())
    {
     //recuperation des informations
     int id=ui->ID->text().toInt();
     ui->ID->clear();
     QString email=ui->EMAIL->text();
     ui->EMAIL->clear();
     QString mdp=ui->MDP->text();
     ui->MDP->clear();
     authentification auth(id,email,mdp);
     bool test=auth.ajouter();
      ui->tableau_2->setModel(auth.afficher());
     if(test)
     {
         QMessageBox::information(nullptr, QObject::tr("ok"),
                                  QObject::tr("Ajout effectué\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);
     }
    }else
         QMessageBox::critical(nullptr, QObject::tr("not nok"),
                                QObject::tr("Ajout non effectué\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_Afficher_clicked()
{
    ui->tableau_2->setModel(auth.afficher());
}

void MainWindow::on_Supprimer_clicked()
{
    if (ui->ID->text().isEmpty())
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("veuillez entrer un id.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else if (auth.authentificationExist(ui->ID->text().toInt())==0)
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("authen n'existe pas.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else {
    int id=ui->ID->text().toInt();
    ui->ID->clear();
    bool test=auth.supprimer(id);

    ui->tableau_2->setModel(auth.afficher());
    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("ok"),
                                 QObject::tr("Suppression effectué\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else {
        QMessageBox::critical(nullptr, QObject::tr("not nok"),
                               QObject::tr("Suppression non effectué\n"
                                           "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }
}

void MainWindow::on_Modifier_clicked()
{
    if (controlSaisie1()){
    //modifier les valeur de class
    int id=ui->ID->text().toInt();
    ui->ID->clear();
    QString email=ui->EMAIL->text();
    ui->EMAIL->clear();
    QString mdp=ui->MDP->text();
    ui->MDP->clear();
    authentification auth(id,email,mdp);

bool test = auth.modifier(id);
    if(test)
    {
        ui->tableau_2->setModel(auth.afficher());
        QMessageBox::information(nullptr, QObject::tr("OK"),
                    QObject::tr("client modifié.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
       else{
        QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                    QObject::tr("client non modifié.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }

}
}
bool MainWindow::controlSaisie1(){
    QRegExp mailREX("\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b");
    mailREX.setCaseSensitivity(Qt::CaseInsensitive);
    mailREX.setPatternSyntax(QRegExp::RegExp);

    if (

            !(mailREX.exactMatch(ui->EMAIL->text())) ||

            !(ui->MDP->text().contains(QRegExp("^[A-Za-z0-9]+$")))

        )
        return 0;
    else
        return 1;
}
void MainWindow::update_label_emp()
{
    data=A.read_from_arduino();

    if(data=="4")
    {

        QMessageBox::information(nullptr, QObject::tr("Succès"),
                    QObject::tr("Alarme éteinte ! \n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
        erreur=0;
        QDateTime d;
        QSqlQuery query;
        query.prepare("INSERT INTO ARDUINO (date_alarme)" "VALUES (:date)");
        query.bindValue(":date",d.currentDateTime());
        query.exec();
    }

    if(data=="5")
    {

        QMessageBox::information(nullptr, QObject::tr("Succès"),
                    QObject::tr("Connexion avec succées ! LED VERTE allumée pendant 2s \n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
        erreur=0;
    }


}

void MainWindow::on_tri_id_emp_clicked()
{
    ui->tab_emp->setModel(e.tri());
}


//agence

void MainWindow::on_pushButton_ajouter_clicked()
{
    int id=ui->lineEdit_id->text().toInt();
    //QString adresse=ui->lineEdit_adresse->text();
    QString adresse=ui->comboBox_adresse->currentText();
    float budget=ui->lineEdit_budget->text().toFloat();
    int nbr_employe=ui->lineEdit_nbr_employe->text().toInt();
    //int nbr_client=ui->lineEdit_nbr_client->text().toInt();
    //int nbr_bien=ui->lineEdit_nbr_bien->text().toInt();
    Agence ag(id,adresse,budget,nbr_employe,0,0);
    int k=ag.get_id();

    if (id == NULL) {
            QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                  QObject::tr("Il faut saisir un ID !"), QMessageBox::Cancel);
        } else if (adresse == NULL) {
            QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                  QObject::tr("Il faut saisir une adresse !"), QMessageBox::Cancel);
        } else if (budget == NULL) {
            QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                  QObject::tr("Il faut saisir un budget !"), QMessageBox::Cancel);
        } else if (nbr_employe == NULL) {
            QMessageBox::critical(nullptr, QObject::tr("not OK"),
                                  QObject::tr("Il faut saisir un nombre d'employés !"), QMessageBox::Cancel);
        }
          else if (ag.agence_exist(ui->lineEdit_supprimer->text().toInt()) != 0) {
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("Agence Déja existante ! \n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
        }
    else {
      bool test=ag.ajouter();
     if(test)
    {
         ui->tableView->setModel(Etmp.afficher());
        QMessageBox::information(nullptr, QObject::tr("OK"),
                              QObject::tr("Ajout effectué.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        QString textajouter;
        historique h;
        QSqlQuery qry;
        qry.prepare("select * from AGENCE");
        textajouter="L'ajout d'une agence a la base de donnees d' ID : "+QString::number(k)+" a ete effectue avec succees";
        h.write(textajouter);

          }
              else
                  QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                              QObject::tr("Ajout non effectué.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
    }
}


//Supprimer
void MainWindow::on_pushButton_supprimer_clicked()
{
    Agence ag;
    if (ui->lineEdit_supprimer->text().isEmpty())
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("veuillez entrer un id.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else if (ag.agence_exist(ui->lineEdit_supprimer->text().toInt())==0)
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("Agence n'existe pas.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else {
    int id=ui->lineEdit_supprimer->text().toInt();
    int k=id;
    bool test=Etmp.supprimer(id);

    if(test)
    {
         ui->tableView->setModel(Etmp.afficher());
        QMessageBox::information(nullptr, QObject::tr("OK"),
                              QObject::tr("Suppression effectuée.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        QString textajouter;
        historique h;
        QSqlQuery qry;
        qry.prepare("select * from AGENCE");
        textajouter="La suppression d'une agence a la base de donnees d' ID : "+QString::number(k)+" a ete effectue avec succees";
        h.write(textajouter);

          }
              else
                  QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                              QObject::tr("Suppression non effectué.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
}
}



void MainWindow::on_pushButton_modifier_clicked()
{
    int id=ui->lineEdit_id->text().toInt();
    //QString adresse=ui->lineEdit_adresse->text();
    QString adresse=ui->comboBox_adresse->currentText();
    float budget=ui->lineEdit_budget->text().toFloat();
    int nbr_employe=ui->lineEdit_nbr_employe->text().toInt();
    Agence ag(id,adresse,budget,nbr_employe);
    int k=ag.get_id();
    if (ui->lineEdit_id->text().isEmpty())
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("veuillez entrer un id.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else if (ag.agence_exist(ui->lineEdit_id->text().toInt())==0)
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("Agence n'existe pas.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else {

        bool test = ag.modifier();

if(test)
{
    ui->tableView->setModel(Etmp.afficher());
    QMessageBox::information(nullptr, QObject::tr("OK"),
                QObject::tr("agence modifié.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);
    QString textajouter;
    historique h;
    QSqlQuery qry;
    qry.prepare("select * from AGENCE");
    textajouter="La modification d'une agence a la base de donnees d' ID : "+QString::number(k)+" a ete effectue avec succees";
    h.write(textajouter);

}
else
    QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                QObject::tr("agence non modifié.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);
}
}

void MainWindow::on_lineEdit_recherche_textChanged()
{
    Agence ag;
    QString rech=ui->lineEdit_recherche->text();
    ui->tableView->setModel(ag.recherche(rech));
}


void MainWindow::on_pushButton_tri_id_clicked()
{
    Agence ag;
    ui->tableView->setModel(ag.tri_id());
}

void MainWindow::on_pushButton_tri_budget_clicked()
{
    Agence ag;
    ui->tableView->setModel(ag.tri_budget());
}

void MainWindow::on_pushButton_tri_nbr_client_clicked()
{
    Agence ag;
    ui->tableView->setModel(ag.tri_nbr_client());
}

void MainWindow::on_pushButton_tri_nbr_employe_clicked()
{
    Agence ag;
    ui->tableView->setModel(ag.tri_nbr_employe());
}


void MainWindow::on_pushButton_statistique_clicked()
{
    statistique_age sag;
    sag.exec();
}

void MainWindow::on_pushButton_imprimer_clicked()
{
    QString strStream;
                QTextStream out(&strStream);

                const int rowCount = ui->tableView->model()->rowCount();
                const int columnCount = ui->tableView->model()->columnCount();
                QString TT = QDate::currentDate().toString("yyyy/MM/dd");
                out <<"<html>\n"
                      "<head>\n"
                       "<meta Content=\"Text/html; charset=Windows-1251\">\n"
                    << "<title> LISTE DES PRODUITS<title>\n "
                    << "</head>\n"
                    "<body bgcolor=#ffffff link=#5000A0>\n"
                    "<h1 style=\"text-align: center;\"><strong> **LISTE DES AGENCES ** "+TT+"</strong></h1>"
                    "<table style=\"text-align: center; font-size: 20px;\" border=1>\n "
                      "</br> </br>";
                // headers
                out << "<thead><tr bgcolor=#d6e5ff>";
                for (int column = 0; column < columnCount; column++)
                    if (!ui->tableView->isColumnHidden(column))
                        out << QString("<th>%1</th>").arg(ui->tableView->model()->headerData(column, Qt::Horizontal).toString());
                out << "</tr></thead>\n";

                // data table
                for (int row = 0; row < rowCount; row++) {
                    out << "<tr>";
                    for (int column = 0; column < columnCount; column++) {
                        if (!ui->tableView->isColumnHidden(column)) {
                            QString data =ui->tableView->model()->data(ui->tableView->model()->index(row, column)).toString().simplified();
                            out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
                        }
                    }
                    out << "</tr>\n";
                }
                out <<  "</table>\n"
                    "</body>\n"
                    "</html>\n";

                QTextDocument *document = new QTextDocument();
                document->setHtml(strStream);

                //QPrinter printer;
                QPrinter printer;

                QPrintDialog *test = new QPrintDialog(&printer, NULL);
                if (test->exec() == QDialog::Accepted) {
                    document->print(&printer);
                }

                delete document;

}

void MainWindow::on_login_clicked()
{
    QString email = ui->email_login->text();
       QString mdp = ui->mdp_login->text();
       int test;
       test=e.login(email,mdp);
           if (test==0)
           {
               erreur++;
               if (erreur>=3) /* alarme on */
               {

                   A.write_to_arduino("2"); //envoyer 1 à arduino
                  QMessageBox::critical(nullptr, QObject::tr("Echèc"),
                              QObject::tr("Mot de passe ou email non valide.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);

               }
               else
               {
                   A.write_to_arduino("1"); //envoyer 1 à arduino
                   QMessageBox::critical(nullptr, QObject::tr("Echèc"),
                               QObject::tr("Mot de passe ou email non valide.\n"
                                           "Click Cancel to exit."), QMessageBox::Cancel); /*led rouge on , */
               }
            }

           else
           {
               erreur=0; /*log in valid */
               A.write_to_arduino("0"); //envoyer 0 à arduino
    ui->stackedWidget->setCurrentIndex(0);

           }
}


void MainWindow::on_rechercher_emp_textChanged(const QString &arg1)
{
    QString rech1=ui->rechercher_emp->text();
    ui->tab_emp->setModel(e.rechercher(rech1));
}
 //bien

void MainWindow::myfunction()
{
    QTime time = QTime::currentTime();
    QString time_text = time.toString("hh : mm : ss");
    if ((time.second()% 2)==0)
    {
        time_text[3] = ' ';
        time_text[8] = ' ';
    }
    ui->label_15->setText(time_text);
}
bool MainWindow::controlSaisiebien(){

    if(ui->id_2->text()=="")
    {
        ui->error->setText("Tapez L'id ");
        return false;
    }
    else if(ui->categorie_2->text()=="")
    {
        ui->error->setText("tapez la categorie");
        return false;
    }
    else if(ui->prix_2->text()=="")
    {
       ui->error->setText("tapez le prix");
      return false;
    }


    else if(ui->adresse_2->text()=="" )
    {
        ui->error->setText("Tapez l' adresse");
        return false;
    }

   /* else if(ui->statut->text()=="" )
    {
        ui->error->setText("Tapez la statu");
        return false;
    }*/
    else
        return true;
}
bool MainWindow::controlSaisiemodif(){

    if(ui->id_modif_2->text()=="")
    {
        ui->error->setText("Tapez L'id ");
        return false;
    }
    else if(ui->catg_modif2->text()=="")
    {
        ui->error->setText("tapez la categorie");
        return false;
    }
    else if(ui->prix_modif2->text()=="")
    {
       ui->error->setText("tapez le prix");
      return false;
    }


    else if(ui->adresse_modif_2->text()=="" )
    {
        ui->error->setText("Tapez l' adresse");
        return false;
    }


    else
        return true;
}
void MainWindow::on_statistique_bien_clicked()
{

    sb.make();
    sb.show();
}

void MainWindow::on_supprimer_bien_clicked()
{


    int id = ui->id_supp_2->text().toInt();
    ui->id->clear();
     bool test=b.supprimer(id);
     if(test){
                         QMessageBox::information(nullptr, QObject::tr("SuccÃ¨s"),
                                     QObject::tr("Bien supprimÃ© avec succÃ¨s.\n"
                                                 "Click Cancel to exit."), QMessageBox::Cancel);
ui->tab_bien_2->setModel(b.afficher());}
}

void MainWindow::on_actualiser_clicked()
{
    ui->tab_bien_2->setModel(b.afficher());
}

void MainWindow::on_modifier_bien_clicked()
{
    if(controlSaisiemodif())
       {

       QString catg= ui->catg_modif2->text();
       ui->catg_modif2->clear();
       QString prix = ui->prix_modif2->text();
       ui->prix_modif2->clear();
       QString statut = ui->satut_modif->currentText();

       QString adresse = ui->adresse_modif_2->text();
       ui->adresse_modif_2->clear();
       int id = ui->id_modif_2->text().toInt();
       ui->id_modif_2->clear();

        ui->tab_bien_2->setModel(b.afficher());
       QMessageBox::information(nullptr,"Information","BIEN modifiÃ© avec succÃ¨s !");
                            QSqlQuery query1,query2,query4,query5;

                                query1.prepare("UPDATE BIEN SET PRIX = ? WHERE ID = ?");
                                query1.addBindValue(prix);

                                query1.addBindValue(id);
                                  query1.exec();

                                  query2.prepare("UPDATE BIEN SET statut = ? WHERE ID = ?");
                                  query2.addBindValue(statut);

                                  query2.addBindValue(id);
                                  query2.exec();


                                  query4.prepare("UPDATE BIEN SET ADRESSE = ? WHERE ID = ?");
                                  query4.addBindValue(adresse);

                                  query4.addBindValue(id);
                                  query4.exec();

                                  query5.prepare("UPDATE BIEN SET CATEGORIE = ? WHERE ID = ?");
                                  query5.addBindValue(catg);

                                  query5.addBindValue(id);
                                  query5.exec();
       }

}

void MainWindow::on_ajouter_bien_clicked()
{
    if(controlSaisiebien()){
    int id = ui->id_2->text().toInt();
     ui->id_2->clear();
    QString categorie = ui->categorie_2->text();
    ui->categorie_2->clear();
    QString statut = ui->statu->currentText();

    QString adresse = ui->adresse_2->text();
    ui->adresse_2->clear();
    int prix = ui->prix_2->text().toInt();
    ui->prix_2->clear();
    bien b(id,categorie,prix,adresse,statut);
    bool test=b.ajouter();
            if(test)
            {
                QMessageBox::information(nullptr, QObject::tr("Succès"),
                            QObject::tr("Bien ajout avec succès.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
            }

ui->tab_bien_2->setModel(b.afficher());
    }else{
        QMessageBox::information(nullptr, QObject::tr("Succès"),
                    QObject::tr("Bien non ajouter.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }
}

void MainWindow::on_rechercher_bien_textChanged(const QString &arg1)
{

    ui->tab_bien_2->setModel(b.chercherbien(ui->rechercher_bien->text()));

}

void MainWindow::on_comboBox_activated(const QString &arg1)
{
    ui->tab_bien_2->setModel( b.tri_bien(ui->comboBox->currentIndex()));
}

//reclamation
void MainWindow::on_pushButton_ajouter_2_clicked()
{
    if (controlSaisierec())
    {
     //recuperation des informations
        QString date=ui->lineEdit_date->text();
          ui->lineEdit_date->clear();

          QString description=ui->lineEdit_description->text();
          ui->lineEdit_description->clear();

       QString titre=ui->lineEdit_titre->text();
       ui->lineEdit_titre->clear();

       QString type=ui->lientype->text();
       ui->lientype->clear();

       int id=ui->lineEditIDreclamation->text().toInt();
       ui->lineEditIDreclamation->clear();

     recl r(id,type,date,titre,description);

     bool test=r.ajouter();
      ui->tableaurec->setModel(r.afficher());
      A.write_to_arduino("1");//arduino


    if(test)
     {
         QMessageBox::information(nullptr, QObject::tr("ok"),
                                  QObject::tr("Ajout effectué\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);
         A.write_to_arduino("1");//arduino
     }
    }else
         QMessageBox::critical(nullptr, QObject::tr("not nok"),
                                QObject::tr("Ajout non effectué\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pushButton_modifier_2_clicked()
{
    if (controlSaisierec()){
    //modifier les valeur de class
        QString date=ui->lineEdit_date->text();
        ui->lineEdit_date->clear();

        QString description=ui->lineEdit_description->text();
        ui->lineEdit_description->clear();

    QString titre=ui->lineEdit_titre->text();
    ui->lineEdit_titre->clear();


    QString type=ui->lientype->text();
    ui->lientype->clear();

    int id=ui->lineEditIDreclamation->text().toInt();
    ui->lineEditIDreclamation->clear();

  recl r(id,type,date,titre,description);

bool test = r.update(id);
if(test)
{
    ui->tableau->setModel(r.afficher());
    QMessageBox::information(nullptr, QObject::tr("OK"),
                QObject::tr("reclamation modifié.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}
    }else
    QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                QObject::tr("reclamation non modifié.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pushButton_ajouter_3_clicked()//afficher
{
     ui->tableaurec->setModel(r.afficher());
}

void MainWindow::on_pushButton_supprimer_2_clicked()
{
    if (ui->lineEditID->text().isEmpty())
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("veuillez entrer un id.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else if (r.recExist(ui->lineEditID->text().toInt())==0)
        QMessageBox::critical(nullptr, QObject::tr("fail"),
                    QObject::tr("reclamation n'existe pas.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    else {
    int id=ui->lineEditID->text().toInt();
  /*  ui->lineEditID->clear();*/
    bool test=r.supprimer(id);

    ui->tableaurec->setModel(r.afficher());

    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("ok"),
                                 QObject::tr("Suppression effectué\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else {
        QMessageBox::critical(nullptr, QObject::tr("not ok"),
                               QObject::tr("Suppression non effectué\n"
                                           "Click Cancel to exit."), QMessageBox::Cancel);
    }
}
}
bool MainWindow::controlSaisierec(){
    QRegExp mailREX("\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b");
    mailREX.setCaseSensitivity(Qt::CaseInsensitive);
    mailREX.setPatternSyntax(QRegExp::RegExp);

    if (
            !(ui->lientype->text().contains(QRegExp("^[A-Za-z]+$"))) ||


            !(ui->lineEdit_titre->text().contains(QRegExp("^[A-Za-z]+$")))

                )
        return 0;
    else
        return 1;
}
void MainWindow::on_pushButton_merier1_3_clicked()//notif
{

    bool test=r.ajouter();

    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("IMPORTANT"),
                                 QObject::tr("VOUS AVEZ UNE RECLAMATION\n"
                                             "Click Cancel POUR L'AFFICHER"), QMessageBox::Cancel);
    }
    else
        QMessageBox::critical(nullptr, QObject::tr("RIEN"),
                               QObject::tr("VOUS N'AVEZ PAS DE NOUVELLE RECLAMATION\n"
                                           "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_pushButton_merier1_2_clicked()
{
    statistique_rec srec;
    srec.exec();
}

void MainWindow::on_pushButton_7_clicked()
{
     ui->tableaurec->setModel(r.triParId());
}

void MainWindow::on_rechercher_rec_textChanged(const QString &arg1)
{
    QString rech=ui->rechercher_rec->text();
    ui->tableaurec->setModel(r.recherche(rech));
}
