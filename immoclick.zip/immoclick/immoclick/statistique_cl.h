#ifndef STATISTIQUE_CL_H
#define STATISTIQUE_CL_H


#include <QDialog>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QPainter>
#include <QSqlQuery>

using namespace std;

namespace Ui {
class statistique_cl;
}

class statistique_cl: public QDialog
{
    Q_OBJECT

public:
    explicit statistique_cl(QWidget *parent = nullptr);
    int statistique_cl_partie2() ;
        int statistique_cl_partie3() ;
         int statistique_cl_partie4() ;
         int statistique_cl_partie5() ;
         int statistique_cl_partie6() ;
        void paintEvent(QPaintEvent *) ;

    ~statistique_cl();

private:
    Ui::statistique_cl *ui;
private slots :
};
#endif // STATISTIQUE_CL_H
