#ifndef AUTHENTIFICATION_H
#define AUTHENTIFICATION_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class authentification
{


    QString email, mdp;
    int id;
public:
   //constructeurs
        authentification(){}
        authentification(int,QString,QString);
        //getters
        QString getEmail(){return email;}
         QString getMdp(){return mdp;}
        int getId(){return id;}
        //stters
        void setEmail(QString em){email=em;}
        void setMdp(QString md){mdp=md;}
        void setId(int id){this->id=id;}
        //fonctionnalites de base
        bool ajouter();
        QSqlQueryModel*afficher();
        bool supprimer(int);
        bool modifier(int id);
         bool authentificationExist(int id);
};

#endif // AUTHENTIFICATION_H
