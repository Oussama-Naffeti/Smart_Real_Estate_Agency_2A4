#ifndef BIEN_H
#define BIEN_H

#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
class bien
{



public:
    //Constructeurs
        bien();
        bien(int, QString, int, QString, QString);

    //Getters

        QString get_Categorie_c();
        int get_Prix_c();
        QString get_Address();
         QString get_Statut();
         int get_id();

    //Setters

        void set_cat(QString);
        void set_prix(int);
        void set_adresse(QString);
         void set_stat(QString );
         void set_id(int );



        bool ajouter();
        QSqlQueryModel * afficher();
        bool supprimer(int id);
        bool modifier(int id);
        bool bienExist(int id);
        QSqlQueryModel * chercherbien(QString r);
        QSqlQueryModel * tri_bien(int tri) ;
private:
        QString  categorie, adresse, statut;
        int id,prix;

};

#endif // CLIENT_H


